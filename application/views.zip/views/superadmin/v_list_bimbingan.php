<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title"><?= $title; ?></h4>
                                    </div>
                                    <div class="col-md-3 col-4">
                                        <!-- <div class="box-controls pull-right"> -->


                                        <!-- </div> -->
                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Nama Dosen</th>
                                                <th>Email</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($users as $usr) {

                                            ?>
                                                <tr>

                                                    <td><?= $usr['nama_user'] ?></td>
                                                    <td><?= $usr['email'] ?></td>


                                                    <td>

                                                        <a href="<?= base_url('superadmin/bimbingan/delete/' . encrypt_url($usr['id_bimbingan']) . '/' . encrypt_url($id_dosen)) ?>" class="btn btn-icon btn-light-danger tombol-hapus">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </td>

                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>