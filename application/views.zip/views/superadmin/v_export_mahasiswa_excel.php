    <table style="width:100%" border="1">
        <thead>
            <tr>
                <th>Nama Mahasiswa</th>
                <th>Jenis Kelamin</th>
                <th>NISN</th>
                <!-- <th>NIK</th> -->
                <th>Tempat Lahir</th>
                <th>Tanggal Lahir</th>
                <th>Agama</th>
                <th>Kewarganegaraan</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // var_dump($mahasiswa);
            // die;
            foreach ($mahasiswa as $p) { ?>
                <tr>
                    <td><?= $p['nm_pd'] ?></td>
                    <td><?= $p['jk'] ?></td>
                    <td><?= $p['nisn'] ?></td>
                    <!-- <td><?= $p['nik'] ?></td> -->
                    <td><?= $p['tmpt_lahir'] ?></td>
                    <td><?= $p['tgl_lahir'] ?></td>
                    <td><?= $p['nm_agama'] ?></td>
                    <td><?= $p['nm_wil'] ?></td>
                </tr>
            <?php } ?>
        </tbody>

    </table>