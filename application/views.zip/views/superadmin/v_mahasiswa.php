<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title">Management Mahasiswa</h4>
                                        <a href="<?= base_url('superadmin/mahasiswa/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a>
                                        <a href="<?= base_url('superadmin/mahasiswa/exportpdf') ?>" class="btn btn-sm btn-danger">Export PDF</a>
                                        <span href="<?= base_url('superadmin/mahasiswa/exportpdf') ?>" class="btn btn-sm btn-info" data-toggle="modal" data-target="#importdata">+ Import data mahasiswa</span>
                                    </div>
                                    <div class="col-md-3 col-4">
                                        <!-- <div class="box-controls pull-right"> -->
                                        <a data-flashdata="mahasiswa" href="<?= base_url('superadmin/mahasiswa/add/') ?>" class="btn btn-success btn-sm btn-xs align-middle float-right">
                                            <i class="fas fa-plus"></i>
                                            Tambah Mahasiswa Baru
                                        </a>
                                        <!-- </div> -->
                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body  with-border">
                                <div class="table-responsive">
                                    <table class="table table-hover " id="table">
                                        <thead>
                                            <tr>
                                                <th>Nama Mahasiswa</th>
                                                <th>JK</th>
                                                <th>NIM</th>
                                                <!-- <th>NIK</th> -->
                                                <th>Tempat Lahir</th>
                                                <th>Tanggal Lahir</th>
                                                <th>Agama</th>
                                                <th>Kewarganegaraan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // var_dump($mahasiswa);
                                            // die;
                                            foreach ($mahasiswa as $p) { ?>
                                                <tr>
                                                    <td><?= $p['nm_pd'] ?></td>
                                                    <td><?= $p['jk'] ?></td>
                                                    <td><?= $p['username'] ?></td>
                                                    <!-- <td><?= $p['nik'] ?></td> -->
                                                    <td><?= $p['tmpt_lahir'] ?></td>
                                                    <td><?= $p['tgl_lahir'] ?></td>
                                                    <td><?= $p['nm_agama'] ?></td>
                                                    <td><?= $p['nm_wil'] ?></td>
                                                    <td>
                                                        <!-- <button type="button" data-toggle="modal" data-target="#modalEdit<?= $p['id'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button> -->
                                                        <a data-flashdata="mahasiswa" href="<?= base_url('superadmin/mahasiswa/detailEdit/' . $p['id']) ?>" class="waves-effect waves-circle btn btn-xs btn-circle btn-success mb-5"><i class="fa fa-pen"></i></a>
                                                        <a data-flashdata="mahasiswa" href="<?= base_url('superadmin/mahasiswa/delete/' . $p['id']) ?>" class="waves-effect waves-circle btn btn-xs btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a>

                                                    </td>
                                                </tr>
                                            <?php } ?>


                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Nama Mahasiswa</th>
                                                <th>Jenis Kelamin</th>
                                                <th>NIM</th>
                                                <!-- <th>NIK</th> -->
                                                <th>Tempat Lahir</th>
                                                <th>Tanggal Lahir</th>
                                                <th>Agama</th>
                                                <th>Kewarganegaraan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="importdata">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Import Data Mahasiswa</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <form action="<?= base_url('superadmin/mahasiswa/importMahasiswa') ?>" method="POST" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">File harus dalam bentuk <b>.xlx</b> atau <b>.csv</b> dan sesuai format. <a target="blank" class="badge badge-success" href="<?= base_url('assets/panduan/Format Import Data Mahasiswa.pdf') ?>">Download Format</a></label>
                                            <input type="file" class="form-control" id="exampleInputEmail1" required name="file">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    <!-- /.card-body -->

            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->