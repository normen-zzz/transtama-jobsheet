<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title"><?= $title ?></h4>
                                        <!-- <a href="<?= base_url('superadmin/users/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a>
                                        <a href="<?= base_url('superadmin/users/exportpdf') ?>" class="btn btn-sm btn-danger">Export PDF</a> -->
                                    </div>
                                    <div class="col-md-3 col-4">

                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Matakuliah</th>
                                                <th>Dosen</th>
                                                <th>Hari</th>
                                                <th>Tanggal</th>
                                                <th>Jam</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($classes as $clas) { ?>
                                                <tr>

                                                    <td><?= $clas['nama_mk'] ?></td>
                                                    <td><?= $clas['nama_user'] ?></td>
                                                    <td><?= $clas['hari'] ?></td>
                                                    <td><?= bulan_indo($clas['tgl_mulai']) ?> /<br> <?= bulan_indo($clas['tgl_selesai']) ?></td>

                                                    <td><?= $clas['jam_mulai'] ?> - <?= $clas['jam_selesai'] ?></td>
                                                    <!-- <td></td> -->
                                                    <!-- <td><?= ($clas['status'] == 1) ? 'Aktif' : 'Tidak aktif'; ?></td> -->
                                                    <td>
                                                        <a href="<?= base_url('superadmin/classes/beritaAcara/' . encrypt_url($clas['id_kelas']) . '/' . encrypt_url($clas['id_user'])) ?>" class="badge badge-success">Lihat Berita Acara</a>
                                                    </td>

                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>