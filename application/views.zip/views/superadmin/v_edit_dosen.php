<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <?php
                                // var_dump($dosenhasiswa);
                                ?>
                                <h4 class="modal-title">Edit Data <?= $dosen['nm_sdm'] ?></h4>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body  with-border">

                                <form action="<?= base_url('superadmin/dosen/edit') ?>" method="POST">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="row">
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Nama Dosen</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="nm_sdm" value="<?= $dosen['nm_sdm']; ?>">
                                                            <input type="text" hidden class="form-control" id="exampleInputEmail1" required name="id_sdm" value="<?= $dosen['id_sdm'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Jenis Kelamin</label>
                                                            <select class="form-control" aria-label="Default select example" name="jk">
                                                                <option value="L" <?php if ($dosen['jk'] == 'L') {
                                                                                        echo 'selected';
                                                                                    } ?>>Laki-Laki</option>
                                                                <option value="P" <?php if ($dosen['jk'] == 'P') {
                                                                                        echo 'selected';
                                                                                    } ?>>Perempuan</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tempat Lahir</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="tmpt_lahir" value="<?= $dosen['tmpt_lahir']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tanggal Lahir</label>
                                                            <input type="date" class="form-control" id="exampleInputEmail1" required name="tgl_lahir" value="<?= $dosen['tgl_lahir']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Status</label>
                                                            <select class="form-control" aria-label="Default select example" name="stat_kawin">
                                                                <option value="0" <?php if ($dosen['stat_kawin'] == 0) {
                                                                                        echo 'selected';
                                                                                    } ?>>Lajang</option>
                                                                <option value="1" <?php if ($dosen['stat_kawin'] == 1) {
                                                                                        echo 'selected';
                                                                                    } ?>>Menikah</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">NIP</label>
                                                            <input type="number" class="form-control" id="exampleInputEmail1" required name="nip" value="<?= $dosen['nip']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">NIDN</label>
                                                            <input type="number" class="form-control" id="exampleInputEmail1" required name="nidn" value="<?= $dosen['nidn']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">NPWP</label>
                                                            <input type="number" class="form-control" id="exampleInputEmail1" required name="npwp" value="<?= $dosen['npwp']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">NIK</label>
                                                            <input type="number" class="form-control" id="exampleInputEmail1" required name="nik" value="<?= $dosen['nik']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Alamat</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="jln" value="<?= $dosen['jln']; ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">RT</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="rt" value="<?= $dosen['rt']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">RW</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="rw" value="<?= $dosen['rw']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Kelurahan</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="ds_kel" value="<?= $dosen['ds_kel']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Kode POS</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="kode_pos" value="<?= $dosen['kode_pos']; ?>">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">No Telpon Rumah</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="no_tel_rmh" value="<?= $dosen['no_tel_rmh']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Nomor Handphone</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="no_hp" value="<?= $dosen['no_hp']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Email</label>
                                                            <input type="email" class="form-control" id="exampleInputEmail1" required name="email" value="<?= $dosen['email']; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Kewarganegaraan</label>
                                                            <select class="form-control" aria-label="Default select example" name="kewarganegaraan">
                                                                <?php foreach ($kewarganegaraan as $k) { ?>
                                                                    <option value="<?= $k['kewarganegaraan'] ?>" <?php if ($dosen['kewarganegaraan'] == $k['kewarganegaraan']) {
                                                                                                                        echo "selected";
                                                                                                                    } ?>><?= $k['nm_wil'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Agama</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_agama">
                                                                <?php foreach ($agama as $a) { ?>
                                                                    <option value="<?= $a['id_agama'] ?>" <?php if ($dosen['id_agama'] == $a['id_agama']) {
                                                                                                                echo "selected";
                                                                                                            } ?>><?= $a['nm_agama'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Pangkat</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_pangkat_gol">
                                                                <?php foreach ($pangkat as $pa) { ?>
                                                                    <option value="<?= $pa['id_pangkat'] ?>" <?php if ($dosen['id_pangkat_gol'] == $pa['id_pangkat']) {
                                                                                                                    echo "selected";
                                                                                                                } ?>><?= $pa['nm_pangkat'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Kecamatan</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="kec" value="<?= $dosen['kec'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Kota</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="kota" value="<?= $dosen['kota'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Provinsi</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="propinsi" value="<?= $dosen['propinsi'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Jabfung</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_jabfung">
                                                                <?php foreach ($jabfung as $ja) { ?>
                                                                    <option value="<?= $ja['id_jabfung'] ?>" <?php if ($dosen['id_jabfung'] == $ja['id_jabfung']) {
                                                                                                                    echo "selected";
                                                                                                                } ?>><?= $ja['nm_jabfung'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Status Dosen</label>
                                                            <select class="form-control" aria-label="Default select example" name="statusdosen">
                                                                <option value="0" <?php print ($dosen['statusdosen'] == 0) ? 'selected' : ''; ?>>Non Aktif</option>
                                                                <option value="1" <?php print ($dosen['statusdosen'] == 1) ? 'selected' : ''; ?>>Aktif</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Prodi</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_prodi">
                                                                <?php foreach ($tb_jurusan as $tj) { ?>
                                                                    <option value="<?= $tj['id_prodi'] ?>" <?php print ($tj['id_prodi'] == $dosen['id_prodi']) ? 'selected' : ''; ?>><?= $tj['nama_prodi'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 border-bottom-dark border-1">
                                                        <p class="h4 mb-3 ">S1</p>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">S1 di Universitas</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="s1" value="<?= $dosen['s1'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tahun Lulus S1</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus1" value="<?= $dosen['lulus1'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Gelar S1</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar1" value="<?= $dosen['gelar1'] ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 border-bottom-dark border-1">
                                                        <p class="h4 mb-3 ">S2</p>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">S2 di Universitas</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="s2" value="<?= $dosen['s2'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tahun Lulus S2</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus2" value="<?= $dosen['lulus2'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Gelar S2</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar2" value="<?= $dosen['gelar2'] ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 border-bottom-dark border-1">
                                                        <p class="h4 mb-3 ">S3</p>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">S3 di Universitas</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="s3" value="<?= $dosen['s3'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tahun Lulus S3</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus3" value="<?= $dosen['lulus3'] ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Gelar S3</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar3" value="<?= $dosen['gelar3'] ?>">
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                    <!-- /.card-body -->


                            </div>
                            <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                            </form>

                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
            </div>
        </div>
    </div>
</div>