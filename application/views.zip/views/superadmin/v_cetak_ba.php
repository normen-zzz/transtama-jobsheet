<style>
    table {
        width: 100%;
        font-size: 12pt;

    }

    table,
    th,
    td {
        border-collapse: collapse;
        /* text-align: left; */
        table-layout: fixed;
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        font-size: 13px;

    }

    td {
        color: black;
        word-wrap: break-word;

    }

    h1 {
        font-size: 40px;
        margin-top: 1px;
    }

    .garis {
        border-top: 1px solid black;
        margin-left: 30px;
        margin-right: 40px;
    }

    #nilai {
        text-align: right;
        float: right;
    }

    .footer {
        margin-left: 30px;
        /* margin-top: 230px; */
        position: fixed;
        top: 520px;
    }

    p {
        font-size: 16px;
        font-family: 'Times New Roman', Times, serif;
    }
</style>
<center>
    <!-- header -->
    <br>
    <br>
    <table style="margin-top: -5px; margin-left:40px">
        <tr>
            <td style="width: 18%;">
                <img src="<?= base_url('uploads/logo.png') ?>" width="100" height="100">
            </td>
            <td>
                <span style="margin-left: 10px; font-size:20px; ">S E K O L A H &nbsp; T I N G G I &nbsp; I L M U &nbsp; H U K U M
                </span> <br>
                <b> <span style="margin-left: 60px; font-size: 20px;"> STIH DHARMA ANDIGHA BOGOR</span><br>
                    <span style="margin-left: 80px; font-size: 16px;"> PROGRAM STUDI S1 - ILMU HUKUM</span><br>
                </b>

                <span style="margin-top: 60px;margin-left: 20px; font-size: 11px;">Jl. KH. Sholeh Iskandar No. 69 Kota Bogor 16161, Telp./Fax. : (0251) 8839 7952</span>
                <hr style="width: 88%; margin-left:-10px">
            </td>
            </td>
        </tr>


    </table>

</center>

<!-- content -->
<br>

<div class="content" style="margin-left: 80px; margin-right: 60px;">
    <!-- <hr> -->
    <div class="inv" style="border-bottom: 1px solid black;">
        <center>
            <h2 style="padding-bottom: 10px; padding-top:-20px;">Berita Acara Mengajar</h2>
        </center> <br>
    </div>
    <br>

    <table style="width:100%;">
        <tr>
            <td style="font-family: 'Times New Roman', Times, serif;  font-size: 16px; width:25%">Nama Dosen</td>
            <td style="font-family: 'Times New Roman', Times, serif; font-size: 16px;">: <b> <?= $dosen['nama_user'] ?></b> </td>
        </tr>

        <tr>
            <td style="font-family: 'Times New Roman', Times, serif; font-size: 16px;">Email</td>

            <td style="font-family: 'Times New Roman', Times, serif; font-size: 16px;">: <?= $dosen['username'] ?> </td>
        </tr>

    </table><br><br>

    <table style="width:100%" border="1">
        <thead>
            <tr>
                <th>Pertemuan</th>
                <th>Topik</th>
                <th>Tanggal</th>
                <th>Jam</th>

            </tr>
        </thead>
        <tbody>
            <?php foreach ($ba as $t) { ?>
                <tr>
                    <td><?= $t['pertemuan'] ?></td>
                    <td><?= $t['topik'] ?></td>
                    <td><?= longdate_indo($t['tgl_mengajar']) ?></td>
                    <td><?= $t['jam_mulai'] ?>-<?= $t['jam_selesai'] ?></td>

                </tr>
            <?php } ?>
        </tbody>

    </table><br>

</div>