<!--begin::Entry-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <!--begin::Dashboard-->
        <!--begin::Row-->

        <div class="card card-custom gutter-b example example-compact">
            <div class="card-body">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?= $title; ?></h3>
                    </div>
                    <div class="modal-body">
                        <?php echo $this->session->flashdata('notif') ?>
                    </div>
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="table" class="table table-bordered" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Nama Mahasiswa</th>
                                        <th>Prodi</th>
                                        <th>Fakultas</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($mahasiswa as $p) { ?>
                                        <tr>

                                            <td><?= $p['nama_user'] ?> </td>
                                            <td><?= $p['nama_prodi'] ?></td>
                                            <td><?= $p['nama_fakultas'] ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        </div>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
        </section>
    </div>
</div>