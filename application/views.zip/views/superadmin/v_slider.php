	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<!-- Info boxes -->
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h2 class="card-title">Management Slider</h2>
						</div>
						<!-- /.card-header -->
						<div class="card-body">
							<table id="myTable" class="table table-bordered table-striped">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-lg">
									<i class="fas fa-plus-circle"> Tambah Slider Baru</i>
								</button>
								<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
								<thead>
									<tr>
										<th>Judul</th>
										<th>Link</th>
										<th>Deskripsi</th>
										<th>Gambar</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($slider as $s) { ?>
										<tr>
											<td><?= $s['judul'] ?></td>
											<td><?= $s['link'] ?></td>
											<td><?= $s['deskripsi'] ?></td>
											<td> <a href="<?= base_url('assets/front/img/slide/') . $s['gambar'] ?>"> <img src="<?= base_url('assets/front/img/slide/') . $s['gambar'] ?>" alt="" width="100" height="100"></a> </td>
											<td>
												<div class="btn-group">
													<button type="button" class="btn btn-tool dropdown-toggle" data-toggle="dropdown">
														<i class="fas fa-cog"></i>
													</button>
													<div class="dropdown-menu dropdown-menu-right" role="menu">
														</button>
														<a class="dropdown-item" data-toggle="modal" data-target="#modalEdit<?= $s['id_slider'] ?>">Edit</a>
														<a href="<?= base_url('superadmin/managementFrontend/deleteSlider/' . $s['id_slider'] . '/' . $s['gambar']) ?>" onclick="return confirm('Apakah Anda yakin ?')" class="dropdown-item">Delete</a>

													</div>
												</div>


											</td>
										</tr>
									<?php } ?>

								</tbody>
								<tfoot>
									<tr>
										<th>Judul</th>
										<th>Link</th>
										<th>Deskripsi</th>
										<th>Gambar</th>
										<th>Aksi</th>
									</tr>
								</tfoot>
							</table>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->
				</div>

			</div>
			<!-- /.row -->

		</div>
		<!--/. container-fluid -->
	</section>
	<!-- /.content -->

	<div class="modal fade" id="modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Tambah Slider Baru</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/managementFrontend/simpan') ?>" method="post" enctype="multipart/form-data">
						<div class="card-body">
							<div class="form-group">
								<label for="exampleInputEmail1">Judul</label>
								<input type="text" class="form-control" required name="judul">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Link</label>
								<input type="text" class="form-control" required name="link">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Deskripsi</label>
								<textarea class="form-control" required name="deskripsi"></textarea>
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Gambar</label>
								<input type="file" class="form-control" required name="foto">
							</div>



						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<?php foreach ($slider as $s) { ?>
		<div class="modal fade" id="modalEdit<?= $s['id_slider'] ?>">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit <?= $s['judul'] ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?= base_url('superadmin/managementFrontend/editSlider') ?>" method="POST" enctype="multipart/form-data">
							<div class="card-body">

								<div class="form-group">
									<label for="exampleInputEmail1">Judul</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $s['judul'] ?>" name="judul">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $s['id_slider'] ?>" name="id_slider">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Link</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $s['link'] ?>" name="link">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Deskripsi</label>
									<textarea class="form-control" required name="deskripsi"><?= $s['deskripsi'] ?></textarea>
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Gambar</label>
									<input type="file" class="form-control" name="foto">
								</div>
								<a href="<?= base_url('assets/front/img/slide/') . $s['gambar'] ?>"> <img src="<?= base_url('assets/front/img/slide/') . $s['gambar'] ?>" alt="" width="100" height="100"></a>

							</div>
							<!-- /.card-body -->


					</div>
					<div class="modal-footer justify-content-between">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->

	<?php } ?>