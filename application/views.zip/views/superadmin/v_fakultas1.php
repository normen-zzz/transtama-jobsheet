	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<!-- Info boxes -->
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h2 class="card-title">Management Fakultas</h2>
						</div>
						<!-- /.card-header -->
						<div class="card-body">
							<table id="myTable" class="table table-bordered table-striped">
								<button type="button" class="btn btn-sm  btn-success" data-toggle="modal" data-target="#modal-lg">
									<i class="fas fa-plus-circle"> Tambah Fakultas Baru</i>
								</button>
								<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
								<thead>
									<tr>
										<th>Nama Fakultas</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($fakultas as $f) { ?>
										<tr>
											<td><?= $f['nama_fakultas'] ?></td>
											<td>
												<div class="btn-group">
													<button type="button" class="btn btn-tool dropdown-toggle" data-toggle="dropdown">
														<i class="fas fa-cog"></i>
													</button>
													<div class="dropdown-menu dropdown-menu-right" role="menu">
														</button>
														<a class="dropdown-item" data-toggle="modal" data-target="#modalEdit<?= $f['id_fakultas'] ?>">Edit</a>
														<a href="<?= base_url('superadmin/fakultas/delete/' . $f['id_fakultas']) ?>" onclick="return confirm('Apakah Anda yakin ?')" class="dropdown-item">Delete</a>

													</div>
												</div>


											</td>
										</tr>
									<?php } ?>

								</tbody>
								<tfoot>
									<tr>
										<th>Nama Fakultas</th>
										<th>Aksi</th>
									</tr>
								</tfoot>
							</table>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->
				</div>

			</div>
			<!-- /.row -->

		</div>
		<!--/. container-fluid -->
	</section>
	<!-- /.content -->

	<div class="modal fade" id="modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Tambah Fakultas</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/fakultas/addFakultas') ?>" method="POST">
						<div class="card-body">


							<div class="form-group">
								<label for="exampleInputEmail1">Nama Fakultas</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="nama_fakultas">
							</div>



						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<?php foreach ($fakultas as $f) { ?>
		<div class="modal fade" id="modalEdit<?= $f['id_fakultas'] ?>">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit <?= $f['nama_fakultas'] ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?= base_url('superadmin/fakultas/edit') ?>" method="POST">
							<div class="card-body">

								<div class="form-group">
									<label for="exampleInputEmail1">Nama Fakultas</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $f['nama_fakultas'] ?>" name="nama_fakultas">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $f['id_fakultas'] ?>" name="id_fakultas">
								</div>

							</div>
							<!-- /.card-body -->


					</div>
					<div class="modal-footer justify-content-between">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->

	<?php } ?>