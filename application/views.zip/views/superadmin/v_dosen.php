<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title">Management Dosen</h4>
                                        <a href="<?= base_url('superadmin/dosen/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a>
                                        <a href="<?= base_url('superadmin/dosen/exportpdf') ?>" class="btn btn-sm btn-danger">Export PDF</a>
                                        <a class="btn btn-sm btn-info" data-toggle="modal" data-target="#importdata">+ Import Data Dosen</a>
                                    </div>
                                    <div class="col-md-3 col-4">
                                        <!-- <div class="box-controls pull-right"> -->
                                        <a data-flashdata="mahasiswa" href="<?= base_url('superadmin/dosen/add/') ?>" class="btn btn-success btn-sm btn-xs align-middle float-right">
                                            <i class="fas fa-plus"></i>
                                            Tambah Dosen
                                        </a>
                                        <!-- </div> -->
                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body  with-border">
                                <div class="table-responsive">
                                    <table class="table table-hover " id="table">
                                        <thead>
                                            <tr>
                                                <th>Nama Dosen</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Tempat Lahir</th>
                                                <!-- <th>Tanggal Lahir</th> -->
                                                <th>Status</th>
                                                <th>NIP</th>
                                                <th>NIDN</th>
                                                <th>Agama</th>
                                                <th>Kewarganegaraan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($dosen as $p) { ?>
                                                <tr>
                                                    <td><?= $p['nm_sdm'] ?></td>
                                                    <td><?= $p['jk'] ?></td>
                                                    <td><?= $p['tmpt_lahir'] ?></td>
                                                    <!-- <td><?= $p['tgl_lahir'] ?></td> -->
                                                    <td><?php if ($p['stat_kawin'] == 1) {
                                                            echo 'menikah';
                                                        } else {
                                                            echo 'lajang';
                                                        } ?></td>
                                                    <td><?= $p['nip'] ?></td>
                                                    <td><?= $p['nidn'] ?></td>
                                                    <td><?= $p['nm_agama'] ?></td>
                                                    <td><?= $p['nm_wil'] ?></td>
                                                    <td>
                                                        <!-- <button type="button" data-toggle="modal" data-target="#modalEdit<?= $p['id_sdm'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button> -->
                                                        <a data-flashdata="dosen" href="<?= base_url('superadmin/dosen/detailEdit/' . $p['id_sdm']) ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></a>
                                                        <a data-flashdata="dosen" href="<?= base_url('superadmin/dosen/delete/' . $p['id_sdm']) ?>" class="waves-effect waves-circle btn btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a>

                                                    </td>
                                                </tr>
                                            <?php } ?>


                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Nama Dosen</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Tempat Lahir</th>
                                                <!-- <th>Tanggal Lahir</th> -->
                                                <th>Status</th>
                                                <th>NIP</th>
                                                <th>NIDN</th>
                                                <th>Agama</th>
                                                <th>Kewarganegaraan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="importdata">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Import Data Dosen</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form action="<?= base_url('superadmin/dosen/importDosen') ?>" method="POST" enctype="multipart/form-data">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">File harus dalam bentuk <b>.xlx</b> atau <b>.csv</b> dan sesuai format. <a target="blank" class="badge badge-success" href="<?= base_url('assets/panduan/Format Import Data Dosen.pdf') ?>">Download Format</a></label>
                                                <input type="file" class="form-control" id="exampleInputEmail1" required name="file">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Dosen Baru</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form action="<?= base_url('superadmin/dosen/addDosen') ?>" method="POST">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Nama Dosen</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="nm_sdm">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Jenis Kelamin</label>
                                                <select class="form-control" aria-label="Default select example" name="jk">
                                                    <option value="L">Laki-Laki</option>
                                                    <option value="P">Perempuan</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tempat Lahir</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="tmpt_lahir">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tanggal Lahir</label>
                                                <input type="date" class="form-control" id="exampleInputEmail1" required name="tgl_lahir">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status</label>
                                                <select class="form-control" aria-label="Default select example" name="stat_kawin">
                                                    <option value="0">Lajang</option>
                                                    <option value="1">Menikah</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIP</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nip">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIDN</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nidn">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NPWP</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="npwp">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIK</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nik">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Alamat</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="jln">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">RT</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="rt">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">RW</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="rw">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kelurahan</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="ds_kel">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kode POS</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kode_pos">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">No Telpon Rumah</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="no_tel_rmh">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Nomor Handphone</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="no_hp">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email</label>
                                                <input type="email" class="form-control" id="exampleInputEmail1" required name="email">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kewarganegaraan</label>
                                                <select class="form-control" aria-label="Default select example" name="kewarganegaraan">
                                                    <?php foreach ($kewarganegaraan as $k) { ?>
                                                        <option value="<?= $k['kewarganegaraan'] ?>"><?= $k['nm_wil'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Agama</label>
                                                <select class="form-control" aria-label="Default select example" name="id_agama">
                                                    <?php foreach ($agama as $a) { ?>
                                                        <option value="<?= $a['id_agama'] ?>"><?= $a['nm_agama'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Pangkat</label>
                                                <select class="form-control" aria-label="Default select example" name="id_pangkat_gol">
                                                    <?php foreach ($pangkat as $pa) { ?>
                                                        <option value="<?= $pa['id_pangkat'] ?>"><?= $pa['nm_pangkat'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kecamatan</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kec">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kota</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kota">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Provinsi</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="propinsi">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Jabfung</label>
                                                <select class="form-control" aria-label="Default select example" name="id_jabfung">
                                                    <?php foreach ($jabfung as $ja) { ?>
                                                        <option value="<?= $ja['id_jabfung'] ?>"><?= $ja['nm_jabfung'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status Dosen</label>
                                                <select class="form-control" aria-label="Default select example" name="statusdosen">
                                                    <option value="0">Non Aktif</option>
                                                    <option value="1">Aktif</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Prodi</label>
                                                <select class="form-control" aria-label="Default select example" name="id_prodi">
                                                    <?php foreach ($tb_jurusan as $tj) { ?>
                                                        <option value="<?= $tj['id_prodi'] ?>"><?= $tj['nama_prodi'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S1</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S1 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s1">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S1</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus1">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S1</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S2</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S2 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s2">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S2</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus2">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S2</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar2">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S3</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S3 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s3">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S3</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus3">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S3</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar3">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status</label>
                                                <select class="form-control" aria-label="Default select example" name="aktif">
                                                    <option value="Y">Non Aktif</option>
                                                    <option value="N">Aktif</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.card-body -->

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php foreach ($dosen as $ma) { ?>
    <div class="modal fade" id="modalEdit<?= $ma['id_sdm'] ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Data <?= $ma['nm_sdm'] ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('akademik/dosen/edit') ?>" method="POST">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Nama Dosen</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="nm_sdm" value="<?= $ma['nm_sdm']; ?>">
                                                <input type="text" hidden class="form-control" id="exampleInputEmail1" required name="id_sdm" value="<?= $ma['id_sdm'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Jenis Kelamin</label>
                                                <select class="form-control" aria-label="Default select example" name="jk">
                                                    <option value="L" <?php if ($ma['jk'] == 'L') {
                                                                            echo 'selected';
                                                                        } ?>>Laki-Laki</option>
                                                    <option value="P" <?php if ($ma['jk'] == 'P') {
                                                                            echo 'selected';
                                                                        } ?>>Perempuan</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tempat Lahir</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="tmpt_lahir" value="<?= $ma['tmpt_lahir']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tanggal Lahir</label>
                                                <input type="date" class="form-control" id="exampleInputEmail1" required name="tgl_lahir" value="<?= $ma['tgl_lahir']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status</label>
                                                <select class="form-control" aria-label="Default select example" name="stat_kawin">
                                                    <option value="0" <?php if ($ma['stat_kawin'] == 0) {
                                                                            echo 'selected';
                                                                        } ?>>Lajang</option>
                                                    <option value="1" <?php if ($ma['stat_kawin'] == 1) {
                                                                            echo 'selected';
                                                                        } ?>>Menikah</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIP</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nip" value="<?= $ma['nip']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIDN</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nidn" value="<?= $ma['nidn']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NPWP</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="npwp" value="<?= $ma['npwp']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">NIK</label>
                                                <input type="number" class="form-control" id="exampleInputEmail1" required name="nik" value="<?= $ma['nik']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Alamat</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="jln" value="<?= $ma['jln']; ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">RT</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="rt" value="<?= $ma['rt']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">RW</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="rw" value="<?= $ma['rw']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kelurahan</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="ds_kel" value="<?= $ma['ds_kel']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kode POS</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kode_pos" value="<?= $ma['kode_pos']; ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">No Telpon Rumah</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="no_tel_rmh" value="<?= $ma['no_tel_rmh']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Nomor Handphone</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="no_hp" value="<?= $ma['no_hp']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email</label>
                                                <input type="email" class="form-control" id="exampleInputEmail1" required name="email" value="<?= $ma['email']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kewarganegaraan</label>
                                                <select class="form-control" aria-label="Default select example" name="kewarganegaraan">
                                                    <?php foreach ($kewarganegaraan as $k) { ?>
                                                        <option value="<?= $k['kewarganegaraan'] ?>" <?php if ($ma['kewarganegaraan'] == $k['kewarganegaraan']) {
                                                                                                            echo "selected";
                                                                                                        } ?>><?= $k['nm_wil'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Agama</label>
                                                <select class="form-control" aria-label="Default select example" name="id_agama">
                                                    <?php foreach ($agama as $a) { ?>
                                                        <option value="<?= $a['id_agama'] ?>" <?php if ($ma['id_agama'] == $a['id_agama']) {
                                                                                                    echo "selected";
                                                                                                } ?>><?= $a['nm_agama'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Pangkat</label>
                                                <select class="form-control" aria-label="Default select example" name="id_pangkat_gol">
                                                    <?php foreach ($pangkat as $pa) { ?>
                                                        <option value="<?= $pa['id_pangkat'] ?>" <?php if ($ma['id_pangkat_gol'] == $pa['id_pangkat']) {
                                                                                                        echo "selected";
                                                                                                    } ?>><?= $pa['nm_pangkat'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kecamatan</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kec" value="<?= $ma['kec'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Kota</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="kota" value="<?= $ma['kota'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Provinsi</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="propinsi" value="<?= $ma['propinsi'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Jabfung</label>
                                                <select class="form-control" aria-label="Default select example" name="id_jabfung">
                                                    <?php foreach ($jabfung as $ja) { ?>
                                                        <option value="<?= $ja['id_jabfung'] ?>" <?php if ($ma['id_jabfung'] == $ja['id_jabfung']) {
                                                                                                        echo "selected";
                                                                                                    } ?>><?= $ja['nm_jabfung'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status Dosen</label>
                                                <select class="form-control" aria-label="Default select example" name="statusdosen">
                                                    <option value="0">Non Aktif</option>
                                                    <option value="1">Aktif</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Prodi</label>
                                                <select class="form-control" aria-label="Default select example" name="id_prodi">
                                                    <?php foreach ($tb_jurusan as $tj) { ?>
                                                        <option value="<?= $tj['id_prodi'] ?>"><?= $tj['nama_prodi'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S1</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S1 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s1" value="<?= $ma['s1'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S1</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus1" value="<?= $ma['lulus1'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S1</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar1" value="<?= $ma['gelar1'] ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S2</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S2 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s2" value="<?= $ma['s2'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S2</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus2" value="<?= $ma['lulus2'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S2</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar2" value="<?= $ma['gelar2'] ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 border-bottom-dark border-1">
                                            <p class="h4 mb-3 ">S3</p>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">S3 di Universitas</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="s3" value="<?= $ma['s3'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Tahun Lulus S3</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="lulus3" value="<?= $ma['lulus3'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Gelar S3</label>
                                                <input type="text" class="form-control" id="exampleInputEmail1" required name="gelar3" value="<?= $ma['gelar3'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status</label>
                                                <select class="form-control" aria-label="Default select example" name="statusdosen">
                                                    <option value="Y">Non Aktif</option>
                                                    <option value="N">Aktif</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->


                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

<?php } ?>