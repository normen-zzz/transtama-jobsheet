<style>
    table {
        width: 100%;
        font-size: 12pt;

    }

    table,
    th,
    td {
        border-collapse: collapse;
        /* text-align: left; */
        table-layout: fixed;
        font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        font-size: 13px;

    }

    td {
        color: black;
        word-wrap: break-word;

    }

    h1 {
        font-size: 40px;
        margin-top: 1px;
    }

    .garis {
        border-top: 1px solid black;
        margin-left: 30px;
        margin-right: 40px;
    }

    #nilai {
        text-align: right;
        float: right;
    }

    .footer {
        margin-left: 30px;
        /* margin-top: 230px; */
        position: fixed;
        top: 520px;
    }

    p {
        font-size: 16px;
        font-family: 'Times New Roman', Times, serif;
    }
</style>
<center>
    <!-- header -->
    <br>
    <br>
    <table style="margin-top: -5px; margin-left:40px">
        <tr>
            <td style="width: 18%;">
                <img src="<?= base_url('uploads/logo.png') ?>" width="100" height="100">
            </td>
            <td>
                <span style="margin-left: 10px; font-size:20px; ">S E K O L A H &nbsp; T I N G G I &nbsp; I L M U &nbsp; H U K U M
                </span> <br>
                <b> <span style="margin-left: 60px; font-size: 20px;"> STIH DHARMA ANDIGHA BOGOR</span><br>
                    <span style="margin-left: 80px; font-size: 16px;"> PROGRAM STUDI S1 - ILMU HUKUM</span><br>
                </b>

                <span style="margin-top: 60px;margin-left: 20px; font-size: 11px;">Jl. KH. Sholeh Iskandar No. 69 Kota Bogor 16161, Telp./Fax. : (0251) 8839 7952</span>
                <hr style="width: 88%; margin-left:-10px">
            </td>
            </td>
        </tr>


    </table>

</center>

<!-- content -->
<br>

<div class="content" style="margin-left: 80px; margin-right: 60px;">
    <!-- <hr> -->
    <div class="inv" style="border-bottom: 1px solid black;">
        <center>
            <h2 style="padding-bottom: 10px; padding-top:-20px;">Data Dosen</h2>
        </center> <br>
    </div>
    <br>
    <br>

    <table style="width:100%" border="1">
        <thead>
            <tr>
                <th>Nama Dosen</th>
                <th>Jenis Kelamin</th>
                <th>Tempat Lahir</th>
                <th>Status</th>
                <th>NIP</th>
                <th>NIDN</th>
                <th>Agama</th>
                <th>Kewarganegaraan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dosen as $p) { ?>
                <tr>
                    <td><?= $p['nm_sdm'] ?></td>
                    <td style="text-align: center;"><?= $p['jk'] ?></td>
                    <td><?= $p['tmpt_lahir'] ?></td>
                    <!-- <td><?= $p['tgl_lahir'] ?></td> -->
                    <td style="text-align: center;"><?php if ($p['stat_kawin'] == 1) {
                                                        echo 'menikah';
                                                    } else {
                                                        echo 'lajang';
                                                    } ?></td>
                    <td><?= $p['nip'] ?></td>
                    <td><?= $p['nidn'] ?></td>
                    <td style="text-align: center;"><?= $p['nm_agama'] ?></td>
                    <td style="text-align: center;"><?= $p['nm_wil'] ?></td>
                </tr>
            <?php } ?>
        </tbody>

    </table><br>
    <br><br>
    <br><br><br><br><br>


</div>