<!--begin::Content-->
<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<div class="card card-custom gutter-b">
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="box">
							<div class="box-header with-border">
								<div class="row mb-3">
									<div class="col-md-9 col-8">
										<h4 class="box-title">Manajemen jadwal Matakuliah</h4>
									</div>
									<div class="col-md-3 col-4">
										<!-- <div class="box-controls pull-right"> -->
										<button type="button" class="btn btn-success btn-sm btn-xs align-middle float-right" data-toggle="modal" data-target="#modal-lg">
											<i class="fas fa-plus"></i>
											Tambah jadwal Matakuliah
										</button>
										<!-- </div> -->
									</div>
								</div>
								<form action="<?= base_url('superadmin/jadwalMatakuliah') ?>" method="POST">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="exampleInputPassword1">Pilih Semester</label>
												<select name="id_semester" class="form-control" id="id_semester">
													<option value="">-Pilih Semester-</option>
													<?php foreach ($semester as $s) { ?>
														<option value="<?= $s['id_semester'] ?>"><?= $s['semester'] ?>-<?= $s['nama_semester'] ?> </option>
													<?php } ?>
												</select>
											</div>

										</div>
										<div class="col-md-4">
											<button type="submit" class="btn btn-primary" style="margin-top: 25px;">Lihat</button>
											<!-- <a href="<?= base_url('mahasiswa/JadwalMatakuliah/exportpdf/' . encrypt_url($id_semester)) ?>" class="btn btn-sm btn-danger" style="margin-top: 25px;">Export PDF</a> -->
										</div>


									</div>
								</form>
								<!-- <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div> -->
							</div>
							<!-- /.box-header -->
							<div class="box-body no-padding with-border">
								<div class="table-responsive">
									<table class="table table-hover " id="table">
										<thead>
											<tr>
												<th>Nama Matakuliah</th>
												<th>Tahun Ajaran</th>
												<!-- <th>Kelas</th> -->
												<th>Dosen Pertama</th>
												<th>Dosen Kedua</th>
												<th>Hari</th>
												<th>Ruang</th>
												<th>Jam</th>
												<!-- <th>Kaprodi</th> -->
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($jadwal_matkul as $ja) { ?>
												<tr>
													<td><?= $ja['nama_mk'] ?></td>
													<td><?= $ja['semester'] ?>- <?= $ja['nama_semester'] ?></td>
													<!-- <td><?= $ja['nama_kelas'] ?></td> -->
													<td><?= $ja['dosen1'] ?></td>
													<td><?= $ja['dosen2'] ?></td>
													<td><?= $ja['hari'] ?></td>
													<td><?= $ja['ruang'] ?></td>
													<td><?= $ja['waktu_mulai'] ?> - <?= $ja['waktu_akhir'] ?></td>
													<td>
														<button type="button" data-toggle="modal" data-target="#modalEdit<?= $ja['id'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button>
														<a data-flashdata="jadwal matakuliah" href="<?= base_url('superadmin/jadwalMatakuliah/delete/' . $ja['id']) ?>" class="waves-effect waves-circle btn btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a>

													</td>
												</tr>
											<?php } ?>


										</tbody>

									</table>
								</div>
							</div>
							<!-- /.box-body -->
						</div>
						<!-- /.box -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-lg">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Tambah Jadwal Matakuliah</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('superadmin/jadwalMatakuliah/addJadwalMatakuliah') ?>" method="POST">

					<div class="row">
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Tahun Akademik</label>
								<select class="form-control" aria-label="Default select example" name="id_semester">
									<option selected>Pilih Tahun Akademik</option>
									<?php foreach ($semester as $se) { ?>
										<option value="<?= $se['id_semester'] ?>"><?= $se['semester'] ?> - <?= $se['nama_semester'] ?> </option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">semester</label>
								<select class="form-control" aria-label="Default select example" name="semester" id="pilih_semester">
									<option>Pilih Semester</option>
									<option value="1">semester 1</option>
									<option value="2">semester 2</option>
									<option value="3">semester 3</option>
									<option value="4">semester 4</option>
									<option value="5">semester 5</option>
									<option value="6">semester 6</option>
									<option value="7">semester 7</option>
									<option value="8">semester 8</option>
								</select>
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Nama Matakuliah</label>
								<select class="form-control" aria-label="Default select example" name="id_mk" id="mk_persmester">
									<option selected>Pilih Matakuliah</option>
									<?php foreach ($matakuliah as $ma) { ?>
										<option value="<?= $ma['id_matakuliah'] ?>"><?= $ma['nama_mk'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Dosen Pertama</label>
								<select class="form-control" aria-label="Default select example" name="id_sdm1">
									<option selected>Pilih Dosen</option>
									<?php foreach ($dosen as $do) { ?>
										<option value="<?= $do['id_user'] ?>"><?= $do['nama_user'] ?></option>
									<?php } ?>
								</select>
							</div>

						</div>

						<!-- <div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Kelas</label>
								<select class="form-control" aria-label="Default select example" name="id_kelas">
									<option selected>Pilih Kelas</option>
									<?php foreach ($kelas as $ke) { ?>
										<option value="<?= $ke['id_kelas'] ?>"><?= $ke['nama_kelas'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div> -->

						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Dosen Kedua</label>
								<select class="form-control" aria-label="Default select example" name="id_sdm2">
									<option selected>Pilih Dosen</option>
									<?php foreach ($dosen as $do) { ?>
										<option value="<?= $do['id_user'] ?>"><?= $do['nama_user'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Hari</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="hari">
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Ruang</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="ruang">
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Waktu Awal</label>
								<input type="time" class="form-control" id="exampleInputEmail1" required name="waktu_mulai">
							</div>
						</div>
						<div class="col-6">
							<div class="form-group">
								<label for="exampleInputEmail1">Waktu Akhir</label>
								<input type="time" class="form-control" id="exampleInputEmail1" required name="waktu_akhir">
							</div>
						</div>

					</div>




			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php foreach ($jadwal_matkul as $jm) { ?>
	<div class="modal fade" id="modalEdit<?= $jm['id'] ?>">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Jadwal Matakuliah</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/jadwalMatakuliah/editJadwalMatakuliah') ?>" method="POST">
						<input type="text" hidden name="id" value="<?= $jm['id'] ?>">
						<div class="row">
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Nama Matakuliah</label>
									<select class="form-control" aria-label="Default select example" name="id_mk">
										<option selected>Pilih Matakuliah</option>
										<?php foreach ($matakuliah as $ma) { ?>
											<option value="<?= $ma['id_matakuliah'] ?>" <?php if ($ma['id_matakuliah'] == $jm['id_mk']) {
																							echo "selected";
																						} ?>><?= $ma['nama_mk'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Semester</label>
									<select class="form-control" aria-label="Default select example" name="semester">
										<option selected>Pilih Semester</option>
										<?php foreach ($semester as $se) { ?>
											<option value="<?= $se['id_semester'] ?>" <?php if ($se['id_semester'] == $jm['semester']) {
																							echo "selected";
																						} ?>><?= $se['semester'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Dosen Pertama</label>
									<select class="form-control" aria-label="Default select example" name="id_sdm1">
										<option selected>Pilih Dosen</option>
										<?php foreach ($dosen as $do) { ?>
											<option value="<?= $do['id_user'] ?>" <?php if ($do['id_user'] == $jm['id_sdm1']) {
																						echo "selected";
																					} ?>><?= $do['nama_user'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Dosen Kedua</label>
									<select class="form-control" aria-label="Default select example" name="id_sdm2">
										<option selected>Pilih Dosen</option>
										<?php foreach ($dosen as $do) { ?>
											<option value="<?= $do['id_user'] ?>" <?php if ($do['id_user'] == $jm['id_sdm2']) {
																						echo "selected";
																					} ?>><?= $do['nama_user'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>

							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Hari</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="hari" value="<?= $jm['hari'] ?>">
									<input type="text" class="form-control" id="exampleInputEmail1" hidden required name="id" value="<?= $jm['id'] ?>">
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Ruang</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="ruang" value="<?= $jm['ruang'] ?>">
								</div>
							</div>

							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Waktu Awal</label>
									<input type="time" class="form-control" id="exampleInputEmail1" required name="waktu_mulai" value="<?= $jm['waktu_mulai'] ?>">
								</div>
							</div>
							<div class="col-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Waktu Akhir</label>
									<input type="time" class="form-control" id="exampleInputEmail1" required name="waktu_akhir" value="<?= $jm['waktu_akhir'] ?>">
								</div>
							</div>

						</div>

						<div class="modal-footer justify-content-between">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
		</div>
	</div>

<?php } ?>