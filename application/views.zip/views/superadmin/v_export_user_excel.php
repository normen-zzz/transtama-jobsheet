<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Nama User</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Fakultas</th>
            <th>Jurusan</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($users as $usr) {
        ?>
            <tr>
                <td style="text-align:center;width: 10%;"><?= $no ?></td>
                <!-- <td style="width: 10%; text-align:center"><?= $usr['nama_user'] ?></td>
                    <td style="width: 10%; text-align:center"><?= $usr['total'] ?></td>
 -->
                <td><?= $usr['nama_user'] ?></td>
                <td><?= $usr['username'] ?></td>
                <td><?= $usr['email'] ?></td>
                <td><?= $usr['nama_role'] ?></td>
                <td><?= $usr['nama_fakultas'] ?></td>
                <td><?= $usr['nama_prodi'] ?></td>
                <td><?= ($usr['status'] == 1) ? 'Aktif' : 'Tidak aktif'; ?></td>
            </tr>


        <?php
            $no++;
        }
        ?>
    </tbody>

</table>