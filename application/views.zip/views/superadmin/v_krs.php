<!--begin::Entry-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <!--begin::Dashboard-->
        <!--begin::Row-->

        <div class="card card-custom gutter-b example example-compact">
            <div class="card-body">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?= $title; ?></h3>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Pilih Semester</label>
                                    <select name="id_semester" class="form-control" id="semester">
                                        <option value="">-Pilih Semester-</option>
                                        <?php foreach ($semester as $s) { ?>
                                            <option value="<?= $s['id_semester'] ?>"><?= $s['semester'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                            </div>

                        </div>
                        <!-- <input type="submit" class="btn btn-outline-success mb-2" value="Tambah"></input> -->
                    </div>
                    <!-- <div class="modal-body">
                        <?php echo $this->session->flashdata('notif') ?>
                    </div> -->
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <?= $this->session->flashdata('message3'); ?>
                            <table id="table" class="table table-bordered mb-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Nama</th>
                                        <th>NIM</th>
                                        <th>Semester</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="isi_krs">
                                    <?php foreach ($krs as $p) { ?>
                                        <tr>

                                            <td><?= $p['nama_user'] ?> </td>
                                            <td><?= $p['username'] ?> </td>
                                            <td><?= $p['semester'] ?> </td>
                                            <td><?php if ($p['status'] == 0) {
                                                    echo '<span class="badge badge-primary">Menunggu Konfirmasi Pembimbing</span>';
                                                } else {
                                                    echo '<span class="badge badge-success">Setuju</span>';
                                                } ?> </td>
                                            <td><?= $p['created_at'] ?></td>
                                            <td>
                                                <a href="<?= base_url('superadmin/akademik/viewKrs/' . $p['id_semester'] . '/' . $p['id_mhs']) ?>" class="btn btn-icon btn-light-success">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <a href="<?= base_url('superadmin/akademik/cetakKrs/' . $p['id_semester'] . '/' . $p['id_mhs']) ?>" class="btn btn-icon btn-light-danger">
                                                    <i class="fa fa-print"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>nama</th>
                                        <th>Semester</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="add">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Pembayaran Baru</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('superadmin/keuangan/addPembayaran') ?>" method="POST">


                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Pilih Jenis Pembayaran</label>
                                <select name="id_pembayaran" class="form-control">
                                    <option value="" disabled>-Pilih-</option>
                                    <?php foreach ($list_pembayaran as $s) { ?>
                                        <option value="<?= $s['id_manajemen_pembayaran'] ?>"><?= $s['nama_pembayaran'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                        </div>

                    </div>


            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->