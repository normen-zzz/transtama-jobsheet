	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<!-- Info boxes -->
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h2 class="card-title">Management Layanan</h2>
						</div>
						<!-- /.card-header -->
						<div class="card-body">
							<table id="myTable" class="table table-bordered table-striped">
								<button type="button" class="btn btn-success btn-sm " data-toggle="modal" data-target="#modal-lg">
									<i class="fas fa-plus-circle"> Tambah Layanan Baru</i>
								</button>
								<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
								<thead>
									<tr>
										<th>Nama Layanan</th>
										<th>Link</th>
										<th>Icon</th>
										<th>Color Icon</th>
										<th>Deskripsi</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($layanan as $l) { ?>
										<tr>
											<td><?= $l['nama_layanan'] ?></td>
											<td><?= $l['link'] ?></td>
											<td><?= $l['icon'] ?></td>
											<td><?= $l['color_icon'] ?></td>
											<td><?= $l['deskripsi'] ?></td>
											<td>
												<div class="btn-group">
													<button type="button" class="btn btn-tool dropdown-toggle" data-toggle="dropdown">
														<i class="fas fa-cog"></i>
													</button>
													<div class="dropdown-menu dropdown-menu-right" role="menu">
														</button>
														<a class="dropdown-item" data-toggle="modal" data-target="#modalEdit<?= $l['id'] ?>">Edit</a>
														<a href="<?= base_url('superadmin/managementFrontend/deleteLayanan/' . $l['id']) ?>" onclick="return confirm('Apakah Anda yakin ?')" class="dropdown-item">Delete</a>

													</div>
												</div>


											</td>
										</tr>
									<?php } ?>

								</tbody>
								<tfoot>
									<tr>
										<th>Nama Layanan</th>
										<th>Link</th>
										<th>Icon</th>
										<th>Color Icon</th>
										<th>Deskripsi</th>
										<th>Aksi</th>
									</tr>
								</tfoot>
							</table>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->
				</div>

			</div>
			<!-- /.row -->

		</div>
		<!--/. container-fluid -->
	</section>
	<!-- /.content -->

	<div class="modal fade" id="modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Tambah Layanan Baru</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/managementFrontend/addLayanan') ?>" method="POST">
						<div class="card-body">


							<div class="form-group">
								<label for="exampleInputEmail1">Nama Layanan</label>
								<input type="text" class="form-control" required name="nama_layanan">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Link</label>
								<input type="text" class="form-control" required name="link">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Icon</label>
								<input type="text" class="form-control" required name="icon" placeholder="contoh: bx bx-file">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Icon Color</label>
								<input type="text" class="form-control" required name="color_icon" placeholder="contoh: iconbox-orange">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Deskripsi</label>
								<textarea class="form-control" required name="deskripsi"></textarea>
							</div>



						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<?php foreach ($layanan as $l) { ?>
		<div class="modal fade" id="modalEdit<?= $l['id'] ?>">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit <?= $l['nama_layanan'] ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?= base_url('superadmin/managementFrontend/editLayanan') ?>" method="POST">
							<div class="card-body">

								<div class="form-group">
									<label for="exampleInputEmail1">Nama Layanan</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $l['nama_layanan'] ?>" name="nama_layanan">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $l['id'] ?>" name="id">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Link</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $l['link'] ?>" name="link">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Icon</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $l['icon'] ?>" name="icon">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Icon Color</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $l['color_icon'] ?>" name="color_icon">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Deskripsi</label>
									<textarea class="form-control" required name="deskripsi"><?= $l['deskripsi'] ?></textarea>
								</div>

							</div>
							<!-- /.card-body -->


					</div>
					<div class="modal-footer justify-content-between">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->

	<?php } ?>