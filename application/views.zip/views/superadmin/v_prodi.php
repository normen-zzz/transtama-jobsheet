<!--begin::Content-->
<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<div class="card card-custom gutter-b">
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="box">
							<div class="box-header with-border">
								<div class="row mb-3">
									<div class="col-md-9 col-8">
										<h4 class="box-title">Management Program Studi</h4>
									</div>
									<div class="col-md-3 col-4">
										<!-- <div class="box-controls pull-right"> -->
										<button type="button" class="btn btn-success btn-sm btn-xs align-middle float-right" data-toggle="modal" data-target="#modal-lg">
											<i class="fas fa-plus"></i>
											Tambah Program Studi Baru
										</button>
										<!-- </div> -->
									</div>
								</div>
								<!-- <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div> -->
							</div>
							<!-- /.box-header -->
							<div class="box-body no-padding with-border">
								<div class="table-responsive">
									<table class="table table-hover " id="table">
										<thead>
											<tr>
												<th>Nama Program Studi</th>
												<th>Kode Prodi</th>
												<!-- <th>Status</th> -->
												<th>fakultas</th>
												<th>jenjang</th>
												<!-- <th>Kaprodi</th> -->
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($prodi as $p) { ?>
												<tr>
													<td><?= $p['nama_prodi'] ?></td>
													<td><?= $p['kode_prodi'] ?></td>
													<!-- <td><?= $p['status'] ?></td> -->
													<td><?= $p['nama_fakultas'] ?></td>
													<td><?php if ($p['id_jenjang_didik'] == 0) {
															echo 'S1';
														} elseif ($p['id_jenjang_didik'] == 1) {
															echo 'S2';
														} else {
															echo 'S3';
														} ?></td>
													<td>
														<button type="button" data-toggle="modal" data-target="#modalEdit<?= $p['id_prodi'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button>
														<!-- <a data-flashdata="prodi" href="<?= base_url('superadmin/prodi/delete/' . $p['id_prodi']) ?>" class="waves-effect waves-circle btn btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a> -->

													</td>
												</tr>
											<?php } ?>


										</tbody>

									</table>
								</div>
							</div>
							<!-- /.box-body -->
						</div>
						<!-- /.box -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-lg">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Tambah Program Studi Baru</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('superadmin/prodi/addProdi') ?>" method="POST">
					<div class="card-body">


						<div class="form-group">
							<label for="exampleInputEmail1">Nama Program Studi</label>
							<input type="text" class="form-control" id="exampleInputEmail1" required name="nama_prodi">
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Kode Prodi</label>
							<input type="text" class="form-control" id="exampleInputEmail1" required name="kode_prodi">
						</div>
						<!-- <div class="form-group">
							<label for="exampleInputEmail1">Status</label>
							<select class="form-control" aria-label="Default select example" name="status">
								<option selected>Pilih Status</option>
								<option value="0">Tidak Aktif</option>
								<option value="1">Aktif</option>
							</select>
						</div> -->
						<div class="form-group">
							<label for="exampleInputEmail1">Fakultas</label>
							<select class="form-control" aria-label="Default select example" name="id_fakultas">
								<option selected>Pilih Fakultas</option>
								<?php foreach ($fakultas as $f) { ?>
									<option value="<?= $f['id_fakultas'] ?>"><?= $f['nama_fakultas'] ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Jenjang Pendidikan</label>
							<select class="form-control" aria-label="Default select example" name="id_jenjang_didik">
								<option selected>Pilih Jenjang</option>
								<option value="0">S1</option>
								<option value="1">S2</option>
								<option value="2">S3</option>
							</select>
						</div>


					</div>
					<!-- /.card-body -->


			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php foreach ($prodi as $p) { ?>
	<div class="modal fade" id="modalEdit<?= $p['id_prodi'] ?>">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit <?= $p['nama_prodi'] ?></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/prodi/edit') ?>" method="POST">
						<div class="card-body">

							<div class="form-group">
								<label for="exampleInputEmail1">Nama prodi</label>
								<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $p['nama_prodi'] ?>" name="nama_prodi">
								<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $p['id_prodi'] ?>" name="id_prodi">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Kode Prodi</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="kode_prodi" value="<?= $p['kode_prodi'] ?>">
							</div>
							<!-- <div class="form-group">
								<label for="exampleInputEmail1">Status</label>
								<select class="form-control" aria-label="Default select example" name="status">
									<option>Pilih Status</option>
									<option value="0" <?php if ($p['status'] == 0) {
															echo "selected";
														} ?>>Tidak Aktif</option>
									<option value="1" <?php if ($p['status'] == 1) {
															echo "selected";
														} ?>>Aktif</option>
								</select>
							</div> -->
							<div class="form-group">
								<label for="exampleInputEmail1">Fakultas</label>
								<select class="form-control" aria-label="Default select example" name="id_fakultas">
									<option>Pilih Fakultas</option>
									<?php foreach ($fakultas as $f) { ?>
										<option value="<?= $f['id_fakultas'] ?>" <?php if ($p['id_fakultas'] == $f['id_fakultas']) {
																						echo "selected";
																					} ?>><?= $f['nama_fakultas'] ?></option>
									<?php } ?>
								</select>
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Jenjang Pendidikan</label>
								<select class="form-control" aria-label="Default select example" name="id_jenjang_didik">
									<option>Pilih Jenjang</option>
									<option value="0" <?php if ($p['id_jenjang_didik'] == 0) {
															echo "selected";
														} ?>>S1</option>
									<option value="1" <?php if ($p['id_jenjang_didik'] == 1) {
															echo "selected";
														} ?>>S2</option>
									<option value="2" <?php if ($p['id_jenjang_didik'] == 2) {
															echo "selected";
														} ?>>S3</option>
								</select>
							</div>


						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

<?php } ?>