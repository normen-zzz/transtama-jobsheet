<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title"><?= $title; ?></h4>
                                    </div>
                                    <div class="col-md-3 col-4">
                                        <!-- <div class="box-controls pull-right"> -->


                                        <!-- </div> -->
                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Nama Dosen</th>
                                                <th>Email</th>
                                                <th>Total Bimbingan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($dosen as $usr) {
                                                $get_mhs_bimbingan = $this->db->get_where('tbl_mahasiswa_bimbingan', ['id_dosen' => $usr['id_user']])->num_rows();
                                            ?>
                                                <tr>

                                                    <td><?= $usr['nama_user'] ?></td>
                                                    <td><?= $usr['email'] ?></td>

                                                    <td><?= $get_mhs_bimbingan ?></td>
                                                    <td>

                                                        <a href="#" class="btn btn-icon btn-light-primary" data-toggle="modal" data-target="#modalEdit<?= $usr['id_user'] ?>">
                                                            <i class="fa fa-users"></i>
                                                        </a>
                                                        <a href="<?= base_url('superadmin/bimbingan/listMahasiswaBimbingan/' . encrypt_url($usr['id_user'])) ?>" class="btn btn-icon btn-light-success">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>

                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php foreach ($dosen as $usr) { ?>
    <div class="modal fade" id="modalEdit<?= $usr['id_user'] ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Floating Mahasiwa Bimbingan <?= $usr['nama_user'] ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('superadmin/bimbingan/addMahasiswaBimbingan') ?>" method="POST">
                        <input type="hidden" name="id_dosen" value="<?= $usr['id_user'] ?>">
                        <div class="table-responsive">
                            <table id="example1" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Nama Mahasiswa</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($mahasiswa as $usr) { ?>
                                        <tr>

                                            <td><?= $usr['nama_user'] ?></td>
                                            <td><?= $usr['email'] ?></td>

                                            <td><?= ($usr['status'] == 1) ? 'Aktif' : 'Tidak aktif'; ?></td>
                                            <td>

                                                <input type="checkbox" class="form-control" name="id_mhs[]" value="<?= $usr['id_user'] ?>">
                                            </td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>


                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

<?php } ?>