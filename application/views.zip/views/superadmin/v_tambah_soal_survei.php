<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Education-->
            <div class="d-flex flex-row">
                <!--begin::Content-->
                <div class="flex-row-fluid ml-lg-12">
                    <div class="row">
                    </div>
                    <!--end::Forms Widget 2-->
                    <!--begin::Forms Widget 3-->
                    <div class="card card-custom gutter-b">
                        <div class="row">
                            <div class="col-md-12">

                                <form data-parsley-validate="" class="form-horizontal form-label-left" method="POST" action="<?php echo base_url('dosen/classes/addSoal'); ?>">
                                    <h4 class="text-center">Kategori Soal Essay</h4>
                                    <div class="form-group rec-element2">
                                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Soal 1<span class="required"></span>
                                        </label>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <textarea name="soal[]" id="soal1" cols="4" rows="2" alt="1" required="required" class="form-control"></textarea>

                                        </div>
                                    </div>
                                    <div class="ln_solid"></div>
                                    <div id="nextkolom3" name="nextkolom3"></div>
                                    <button type="button" id="jumlahkolom3" value="1" style="display:none"></button>
                                    <div class="form-group">
                                        <div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3">
                                            <button type="button" class="btn btn-info tambah-form-survei">Tambah Soal</button>
                                            <button type="submit" class="btn btn-success">Simpan</button>
                                        </div>
                                    </div>
                                </form>

                                <!--begin::Forms Widget 8-->


                            </div>

                        </div>
                    </div>
                    <!--end::Forms Widget 3-->


                </div>

            </div>
        </div>
        <!--end::Content-->

    </div>
    <!--end::Education-->
</div>
<!--end::Container-->
</div>
<!--end::Entry-->
</div>
<!--end::Content-->