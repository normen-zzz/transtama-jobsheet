<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <?php
                                // var_dump($mahasiswa);
                                ?>
                                <h4 class="modal-title">Tambah Dosen</h4>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body  with-border">


                                <form action="<?= base_url('superadmin/dosen/addDosen') ?>" method="POST">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="row">
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Nama Dosen</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="nm_sdm">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Jenis Kelamin</label>
                                                            <select class="form-control" aria-label="Default select example" name="jk">
                                                                <option value="L">Laki-Laki</option>
                                                                <option value="P">Perempuan</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tempat Lahir</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="tmpt_lahir">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Tanggal Lahir</label>
                                                            <input type="date" class="form-control" id="exampleInputEmail1" required name="tgl_lahir">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">NIK</label>
                                                            <input type="number" class="form-control" id="exampleInputEmail1" required name="nik">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">No Telpon Rumah</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="no_tel_rmh">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Nomor Handphone</label>
                                                            <input type="text" class="form-control" id="exampleInputEmail1" required name="no_hp">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Email</label>
                                                            <input type="email" class="form-control" id="exampleInputEmail1" required name="email">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Agama</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_agama">
                                                                <?php foreach ($agama as $a) { ?>
                                                                    <option value="<?= $a['id_agama'] ?>"><?= $a['nm_agama'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Jabfung</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_jabfung">
                                                                <?php foreach ($jabfung as $ja) { ?>
                                                                    <option value="<?= $ja['id_jabfung'] ?>"><?= $ja['nm_jabfung'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Status Dosen</label>
                                                            <select class="form-control" aria-label="Default select example" name="statusdosen">
                                                                <option value="0">Non Aktif</option>
                                                                <option value="1">Aktif</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Prodi</label>
                                                            <select class="form-control" aria-label="Default select example" name="id_prodi">
                                                                <?php foreach ($tb_jurusan as $tj) { ?>
                                                                    <option value="<?= $tj['id_prodi'] ?>"><?= $tj['nama_prodi'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>


                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>