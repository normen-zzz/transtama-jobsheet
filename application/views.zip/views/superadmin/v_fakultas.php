<!--begin::Content-->
<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<div class="card card-custom gutter-b">
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="box">
							<div class="box-header with-border">

								<div class="row mb-3">
									<div class="col-md-9 col-8">
										<h4 class="box-title">Management Fakultas</h4>
									</div>
									<div class="col-md-3 col-4">
										<!-- <div class="box-controls pull-right"> -->
										<button type="button" class="btn btn-success btn-sm btn-xs align-middle float-right" data-toggle="modal" data-target="#modal-lg">
											<i class="fas fa-plus"></i>
											Tambah Fakultas Baru
										</button>
										<!-- </div> -->
									</div>
								</div>

							</div>
							<!-- /.box-header -->
							<div class="box-body no-padding with-border">
								<div class="table-responsive">
									<table class="table table-hover ">
										<thead>
											<tr>
												<th>Nama Fakultas</th>
												<th>Initial</th>
												<!-- <th>Id Dekan</th> -->
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($fakultas as $f) { ?>
												<tr>
													<td><?= $f['nama_fakultas'] ?></td>
													<td><?= $f['initial'] ?></td>
													<!-- <td><?= $f['id_dekan'] ?></td> -->
													<td>
														<button type="button" data-toggle="modal" data-target="#modalEdit<?= $f['id_fakultas'] ?>" class="waves-effect waves-circle btn btn-sm btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button>
														<!-- <a data-flashdata="fakultas" href="<?= base_url('superadmin/fakultas/delete/' . $f['id_fakultas']) ?>" class="waves-effect waves-circle btn btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a> -->

													</td>
												</tr>
											<?php } ?>

										</tbody>
									</table>
								</div>
							</div>
							<!-- /.box-body -->
						</div>
						<!-- /.box -->
					</div>
				</div>
				</section>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Tambah Fakultas</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/fakultas/addFakultas') ?>" method="POST">
						<div class="card-body">


							<div class="form-group">
								<label for="exampleInputEmail1">Nama Fakultas</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="nama_fakultas">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Initial</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="initial">
							</div>
							<!-- <div class="form-group">
								<label for="exampleInputEmail1">Id Dekan</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="id_dekan">
							</div> -->

						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<?php foreach ($fakultas as $f) { ?>
		<div class="modal fade" id="modalEdit<?= $f['id_fakultas'] ?>">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit <?= $f['nama_fakultas'] ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?= base_url('superadmin/fakultas/edit') ?>" method="POST">
							<div class="card-body">

								<div class="form-group">
									<label for="exampleInputEmail1">Nama Fakultas</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $f['nama_fakultas'] ?>" name="nama_fakultas">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $f['id_fakultas'] ?>" name="id_fakultas">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Initial</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $f['initial'] ?>" name="initial">
								</div>
								<!-- <div class="form-group">
									<label for="exampleInputEmail1">Id Dekan</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $f['id_dekan'] ?>" name="id_dekan">
								</div> -->

							</div>
							<!-- /.card-body -->


					</div>
					<div class="modal-footer justify-content-between">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->

	<?php } ?>
</div>