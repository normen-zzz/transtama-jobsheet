<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title"><?= $title ?></h4>
                                        <!-- <a href="<?= base_url('superadmin/users/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a> -->
                                        <a href="<?= base_url('superadmin/classes/cetakBeritaAcara/' . encrypt_url($id_kelas) . '/' . encrypt_url($id_user)) ?>" class="btn btn-sm btn-danger">Cetak</a>
                                    </div>
                                    <div class="col-md-3 col-4">

                                    </div>
                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Pertemuan</th>
                                                <th>Topik</th>
                                                <th>Tanggal</th>
                                                <th>Jam</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($ba as $t) { ?>
                                                <tr>
                                                    <td><?= $t['pertemuan'] ?></td>
                                                    <td><?= $t['topik'] ?></td>
                                                    <td><?= longdate_indo($t['tgl_mengajar']) ?></td>
                                                    <td><?= $t['jam_mulai'] ?>-<?= $t['jam_selesai'] ?></td>
                                                    <td>
                                                        <a href="#" data-toggle="modal" data-target="#modal-edit<?= $t['id_berita_acara'] ?>" class="btn btn-icon btn-success"><i class="fas fa-edit"></i></a>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>