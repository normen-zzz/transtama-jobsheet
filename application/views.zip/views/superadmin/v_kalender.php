<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="row mb-3">
                                    <div class="col-md-9 col-8">
                                        <h4 class="box-title"><?= $title ?></h4>
                                    </div>

                                </div>

                            </div>
                            <!-- /.box-header -->
                            <div class="box-body  with-border">
                                <div class="table-responsive">
                                    <table class="table table-hover " id="table">
                                        <thead>
                                            <tr>
                                                <!-- <th>Semester</th> -->
                                                <!-- <th>Fakultas</th> -->
                                                <th>Agenda</th>
                                                <th>Tanggal Awal</th>
                                                <th>Tanggal Akhir</th>
                                                <!-- <th>Aksi</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($kalender as $p) { ?>
                                                <tr>
                                                    <!-- <td><?= $p['semester'] ?></td> -->
                                                    <!-- <td><?= $p['nama_fakultas'] ?></td> -->
                                                    <td><?= $p['nama_agenda'] ?></td>
                                                    <td><?= bulan_indo($p['tgl_awal']) ?></td>
                                                    <td><?= bulan_indo($p['tgl_akhir']) ?></td>

                                                </tr>
                                            <?php } ?>


                                        </tbody>

                                    </table>

                                </div>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                </div>
                </section>
            </div>
        </div>
    </div>
</div>