<!--begin::Content-->
<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<div class="card card-custom gutter-b">
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="box">
							<div class="box-header with-border">
								<div class="row mb-3">
									<div class="col-md-9 col-8">
										<h4 class="box-title">Management Matakuliah</h4>
										<a href="<?= base_url('superadmin/MataKuliah/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a>
										<a href="<?= base_url('superadmin/MataKuliah/exportpdf') ?>" class="btn btn-sm btn-danger">Export PDF</a>
										<span href="<?= base_url('superadmin/Matakuliah/import') ?>" class="btn btn-sm btn-info" data-toggle="modal" data-target="#importdata">+ Import data mahasiswa</span>
									</div>
									<div class="col-md-3 col-4">
										<!-- <div class="box-controls pull-right"> -->
										<button type="button" class="btn btn-success btn-sm btn-xs align-middle float-right" data-toggle="modal" data-target="#modal-lg">
											<i class="fas fa-plus"></i>
											Tambah Matakuliah Baru
										</button>
										<!-- </div> -->
									</div>
								</div>

							</div>
							<!-- /.box-header -->
							<div class="box-body with-border">
								<div class="table-responsive">
									<table class="table table-hover " id="table">
										<thead>
											<tr>
												<th>No</th>
												<th>Kode Matakuliah</th>
												<th>Nama Matakuliah</th>
												<th>Jenis</th>
												<th>SKS</th>
												<th>SKS Materi</th>
												<th>SKS Praktik</th>
												<th>Semester</th>
												<th>Kurikulum</th>
												<!-- <th>Aksi</th> -->
											</tr>
										</thead>
										<tbody>
											<?php

											foreach ($matakuliah as $p) { ?>
												<tr>
													<td><?= ++$start; ?></td>
													<td><?= $p['kode_mk'] ?></td>
													<td><?= $p['nama_mk'] ?></td>
													<td><?= $p['jns_mk'] ?></td>
													<td><?= $p['sks'] ?></td>
													<td><?= $p['sks_tm'] ?></td>
													<td><?= $p['sks_prak'] ?></td>
													<td><?= $p['semester'] ?></td>
													<td><?= $p['nama_kur'] ?></td>
													<!-- <td>
														<button type="button" data-toggle="modal" data-target="#modalEdit<?= $p['id_matakuliah'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-xs mb-5"><i class="fa fa-pen"></i></button>
														<a data-flashdata="matakuliah" href="<?= base_url('superadmin/matakuliah/delete/' . $p['id_matakuliah']) ?>" class="waves-effect waves-circle btn btn-circle btn-danger btn-xs mb-5 tombol-hapus"><i class="fa fa-trash"></i></a>

													</td> -->
												</tr>
											<?php } ?>


										</tbody>

									</table>
								</div>
								<?= $this->pagination->create_links() ?>
							</div>
							<!-- /.box-body -->
						</div>
						<!-- /.box -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="importdata">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Import Data Matakuliah</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>

			<div class="modal-body">
				<form action="<?= base_url('superadmin/matakuliah/importMatakuliah') ?>" method="POST" enctype="multipart/form-data">
					<div class="card-body">
						<div class="row">
							<div class="col-12">
								<div class="row">
									<div class="col-12">
										<div class="form-group">
											<label for="exampleInputEmail1">File harus dalam bentuk <b>.xlx</b> atau <b>.csv</b> dan sesuai format. <a target="blank" class="badge badge-success" href="<?= base_url('assets/panduan/format_import_matakuliah.pdf') ?>">Download Format</a></label>
											<input type="file" class="form-control" id="exampleInputEmail1" required name="file">
										</div>
									</div>
								</div>

							</div>
						</div>

					</div>
					<!-- /.card-body -->

			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<div class="modal fade" id="modal-lg">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Tambah Matakuliah Baru</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('superadmin/matakuliah/addMatkul') ?>" method="POST">

					<div class="row">
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">Kode Matakuliah</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="kode_mk">
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">Nama Matakuliah</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="nama_mk">
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">Kurikulum</label>
								<select class="form-control" aria-label="Default select example" name="id_kurikulum">
									<option>Pilih Kurikulum</option>
									<?php foreach ($kurikulum as $pj) { ?>
										<option value="<?= $pj['id'] ?>"><?= $pj['nama_kur'] ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">Jenis</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="jns_mk">
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">SKS</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="sks">
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">SKS Materi</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="sks_tm">
							</div>
						</div>
						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">SKS Praktik</label>
								<input type="text" class="form-control" id="exampleInputEmail1" required name="sks_prak">
							</div>
						</div>

						<div class="col-md-6 col-12">
							<div class="form-group">
								<label for="exampleInputEmail1">semester</label>
								<select class="form-control" aria-label="Default select example" name="semester">
									<option>Pilih Semester</option>
									<option value="1">semester 1</option>
									<option value="2">semester 2</option>
									<option value="3">semester 3</option>
									<option value="4">semester 4</option>
									<option value="5">semester 5</option>
									<option value="6">semester 6</option>
									<option value="7">semester 7</option>
									<option value="8">semester 8</option>
								</select>
							</div>
						</div>
					</div>



			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php foreach ($matakuliah as $f) { ?>
	<div class="modal fade" id="modalEdit<?= $f['id_matakuliah'] ?>">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit <?= $f['nama_mk'] ?></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/matakuliah/edit') ?>" method="POST">

						<div class="row">
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">Kode Matakuliah</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="kode_mk" value="<?= $f['kode_mk'] ?>">
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">Nama matakuliah</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $f['nama_mk'] ?>" name="nama_mk">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $f['id_matakuliah'] ?>" name="id_matakuliah">
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">Kurikulum</label>
									<select class="form-control" aria-label="Default select example" name="id_kurikulum">
										<option>Pilih Kurikulum</option>
										<?php foreach ($kurikulum as $pj) { ?>
											<option value="<?= $pj['id'] ?>" <?php if ($f['id_kurikulum'] == $pj['id']) {
																					echo 'selected';
																				} ?>><?= $pj['nama_kur'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">Jenis</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="jns_mk" value="<?= $f['jns_mk'] ?>">
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">SKS</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="sks" value="<?= $f['sks'] ?>">
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">SKS Materi</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="sks_tm" value="<?= $f['sks_tm'] ?>">
								</div>
							</div>
							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">SKS Praktik</label>
									<input type="text" class="form-control" id="exampleInputEmail1" required name="sks_prak" value="<?= $f['sks_prak'] ?>">
								</div>
							</div>


							<div class="col-md-6 col-12">
								<div class="form-group">
									<label for="exampleInputEmail1">semester</label>
									<select class="form-control" aria-label="Default select example" name="semester">
										<option>Pilih Semester</option>
										<option <?php print ($f['semester'] == 1) ? 'selected' : ''; ?> value="1">semester 1</option>
										<option <?php print ($f['semester'] == 2) ? 'selected' : ''; ?> value="2">semester 2</option>
										<option <?php print ($f['semester'] == 3) ? 'selected' : ''; ?> value="3">semester 3</option>
										<option <?php print ($f['semester'] == 4) ? 'selected' : ''; ?> value="4">semester 4</option>
										<option <?php print ($f['semester'] == 5) ? 'selected' : ''; ?> value="5">semester 5</option>
										<option <?php print ($f['semester'] == 6) ? 'selected' : ''; ?> value="6">semester 6</option>
										<option <?php print ($f['semester'] == 7) ? 'selected' : ''; ?> value="7">semester 7</option>
										<option <?php print ($f['semester'] == 8) ? 'selected' : ''; ?> value="8">semester 8</option>
									</select>
								</div>
							</div>
						</div>




				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

<?php } ?>