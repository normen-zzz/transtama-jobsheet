<!--begin::Content-->
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-xxl-8">
                <div class="card card-custom gutter-b">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="box ribbon-box">
                                    <div class="ribbon-two ribbon-two-success"><span>Admin</span></div>
                                    <div class="box-header no-border text-center">
                                        <p class="h3">Profil Admin</p>
                                    </div>
                                    <div class="box-body">
                                        <div class="table-responsive">
                                            <table class="table no-border h5">
                                                <tr>
                                                    <td style="width: 30%">Nama</td>
                                                    <td style="width: 70%">: <?= $profile['nama_user'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 30%">Email</td>
                                                    <td style="width: 70%">: <?= $profile['email'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 30%">Username</td>
                                                    <td style="width: 70%">: <?= $profile['username'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 30%">Created At</td>
                                                    <td style="width: 70%">: <?= $profile['created_at'] ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <a href="" data-toggle="modal" data-target="#modalEdit<?= $profile['id_user'] ?>" class="waves-effect waves-circle btn btn-circle btn-success btn-sm mb-5 float-right">
                                            <i class="fa fa-pen"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="modalEdit<?= $profile['id_user'] ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Profile</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('superadmin/profile/editUser') ?>" method="POST">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nama </label>
                                        <input type="text" class="form-control" value="<?= $profile['nama_user'] ?>" name="nama_user">
                                        <input type="text" hidden class="form-control" value="<?= $profile['id_user'] ?>" name="id_user">
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Email</label>
                                        <input type="email" class="form-control" value="<?= $profile['email'] ?>" name="email">
                                    </div>

                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Username</label>
                                        <input type="text" class="form-control" value="<?= $profile['username'] ?>" name="username">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input type="password" class="form-control" placeholder="Isi jika password ingin diubah" name="password">
                                    </div>
                                </div>
                            </div>


                        </div>
                        <!-- /.card-body -->


                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->