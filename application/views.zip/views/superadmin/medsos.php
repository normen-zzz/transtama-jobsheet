	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<!-- Info boxes -->
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h2 class="card-title">Management Media Sosial</h2>
						</div>
						<!-- /.card-header -->
						<div class="card-body">
							<table id="myTable" class="table table-bordered table-striped">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-lg">
									<i class="fas fa-plus-circle"> Tambah Media Sosial Baru</i>
								</button>
								<div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
								<thead>
									<tr>
										<th>Nama Media Sosial</th>
										<th>Link</th>
										<th>Icon</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($medsos as $m) { ?>
										<tr>
											<td><?= $m['nama_medsos'] ?></td>
											<td><?= $m['link'] ?></td>
											<td><?= $m['icon'] ?></td>
											<td>
												<div class="btn-group">
													<button type="button" class="btn btn-tool dropdown-toggle" data-toggle="dropdown">
														<i class="fas fa-cog"></i>
													</button>
													<div class="dropdown-menu dropdown-menu-right" role="menu">
														</button>
														<a class="dropdown-item" data-toggle="modal" data-target="#modalEdit<?= $m['id'] ?>">Edit</a>
														<a href="<?= base_url('superadmin/managementFrontend/deleteMedsos/' . $m['id']) ?>" onclick="return confirm('Apakah Anda yakin ?')" class="dropdown-item">Delete</a>

													</div>
												</div>


											</td>
										</tr>
									<?php } ?>

								</tbody>
								<tfoot>
									<tr>
										<th>Nama Media Sosial</th>
										<th>Link</th>
										<th>Icon</th>
										<th>Aksi</th>
									</tr>
								</tfoot>
							</table>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->
				</div>

			</div>
			<!-- /.row -->

		</div>
		<!--/. container-fluid -->
	</section>
	<!-- /.content -->

	<div class="modal fade" id="modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Tambah Media Sosial Baru</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/managementFrontend/addMedsos') ?>" method="POST">
						<div class="card-body">


							<div class="form-group">
								<label for="exampleInputEmail1">Nama Media Sosial</label>
								<input type="text" class="form-control" required name="nama_medsos">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Link</label>
								<input type="text" class="form-control" required name="link">
							</div>

							<div class="form-group">
								<label for="exampleInputEmail1">Icon</label>
								<input type="text" class="form-control" required name="icon" placeholder="contoh: icofont-facebook">
							</div>



						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<?php foreach ($medsos as $m) { ?>
		<div class="modal fade" id="modalEdit<?= $m['id'] ?>">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit <?= $m['nama_medsos'] ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?= base_url('superadmin/managementFrontend/editMedsos') ?>" method="POST">
							<div class="card-body">

								<div class="form-group">
									<label for="exampleInputEmail1">Nama Media Sosial</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $m['nama_medsos'] ?>" name="nama_medsos">
									<input type="text" hidden class="form-control" id="exampleInputEmail1" value="<?= $m['id'] ?>" name="id">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Link</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $m['link'] ?>" name="link">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Icon</label>
									<input type="text" class="form-control" id="exampleInputEmail1" value="<?= $m['icon'] ?>" name="icon">
								</div>

							</div>
							<!-- /.card-body -->


					</div>
					<div class="modal-footer justify-content-between">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->

	<?php } ?>