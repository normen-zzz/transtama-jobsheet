<!--begin::Content-->
<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<div class="card card-custom gutter-b">
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="box">
							<div class="box-header with-border">
								<div class="row mb-3">
									<div class="col-md-9 col-8">
										<h4 class="box-title">Management User</h4>
										<a href="<?= base_url('superadmin/users/exportexcel') ?>" class="btn btn-sm btn-success">Export Excel</a>
										<a href="<?= base_url('superadmin/users/exportpdf') ?>" class="btn btn-sm btn-danger">Export PDF</a>
									</div>
									<div class="col-md-3 col-4">
										<!-- <div class="box-controls pull-right"> -->
										<?php if ($this->session->userdata('id_jurusan') == 0) {
										?>
											<button type="button" class="btn btn-success btn-sm btn-xs align-middle float-right" data-toggle="modal" data-target="#modal-lg">
												<i class="fas fa-plus"></i>
												Tambah User Baru
											</button>
										<?php	} else {
										} ?>
										<!-- </div> -->
									</div>
								</div>

							</div>
							<!-- /.box-header -->
							<div class="box-body">
								<div class="table-responsive">
									<table id="table" class="table table-hover">
										<thead>
											<tr>
												<th>Nama User</th>
												<th>Username</th>
												<th>Email</th>
												<th>Role</th>
												<th>Fakultas</th>
												<th>Jurusan</th>
												<th>Status</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($users as $usr) { ?>
												<tr>

													<td><?= $usr['nama_user'] ?></td>
													<td><?= $usr['username'] ?></td>
													<td><?= $usr['email'] ?></td>
													<td><?= $usr['nama_role'] ?></td>
													<td><?= $usr['nama_fakultas'] ?></td>
													<td><?= $usr['nama_prodi'] ?></td>
													<td><?= ($usr['status'] == 1) ? 'Aktif' : 'Tidak aktif'; ?></td>
													<td>
														<?php if ($this->session->userdata('id_jurusan') == 0) {
														?>
															<a href="#" class="btn btn-icon btn-light-primary" data-toggle="modal" data-target="#modalEdit<?= $usr['id_user'] ?>">
																<i class="fa fa-pen"></i>
															</a>

															<a data-flashdata="user" href="<?= base_url('superadmin/users/delete/' . $usr['id_user']) ?>" class="btn btn-icon btn-light-danger tombol-hapus mt-1"><i class="fa fa-trash"></i></a>
														<?php } else {
														?>
															<a href="#" class="btn btn-icon btn-light-primary" data-toggle="modal" data-target="#modalEdit<?= $usr['id_user'] ?>">
																<i class="fa fa-pen"></i>
															</a>
														<?php	} ?>
													</td>

												</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
							<!-- /.box-body -->
						</div>
						<!-- /.box -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="modal-lg">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Add New Users</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('superadmin/users/addUser') ?>" method="POST">
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputEmail1">Nama User</label>
									<input type="text" class="form-control" required name="nama_user">
								</div>

							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputPassword1">Email</label>
									<input type="email" class="form-control" required name="email">
								</div>

							</div>

						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputPassword1">Username</label>
									<input type="text" class="form-control" required name="username">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputPassword1">Password</label>
									<input type="password" class="form-control" required name="password">
								</div>
							</div>

						</div>
						<div class="row">

							<div class="col-md-6">

								<div class="form-group">
									<label for="exampleSelectBorder">Fakultas</label>
									<select required name="id_fakultas" class="custom-select form-control-border">

										<?php foreach ($fakultas as $f) { ?>
											<option value="<?= $f['id_fakultas'] ?>"><?= $f['nama_fakultas'] ?></option>
										<?php } ?>

									</select>
								</div>

							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleSelectBorder">Prodi</label>
									<select required name="id_prodi" class="custom-select form-control-border">
										<?php foreach ($jurusan as $j) { ?>
											<option value="<?= $j['id_prodi'] ?>"><?= $j['nama_prodi'] ?></option>
										<?php } ?>


									</select>
								</div>

							</div>
						</div>

						<div class="form-group">
							<label for="exampleSelectBorder">Role</label>
							<select required name="id_role" class="custom-select form-control-border">
								<?php foreach ($roles as $r) { ?>
									<option value="<?= $r['id_role'] ?>"><?= $r['nama_role'] ?></option>
								<?php } ?>


							</select>
						</div>

					</div>
					<!-- /.card-body -->


			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php foreach ($users as $usr) { ?>
	<div class="modal fade" id="modalEdit<?= $usr['id_user'] ?>">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit User <?= $usr['nama_user'] ?></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?= base_url('superadmin/users/editUser') ?>" method="POST">
						<div class="card-body">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleInputEmail1">Nama User</label>
										<input type="text" class="form-control" value="<?= $usr['nama_user'] ?>" name="nama_user">
										<input type="text" hidden class="form-control" value="<?= $usr['id_user'] ?>" name="id_user">
									</div>

								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleInputPassword1">Email</label>
										<input type="email" class="form-control" value="<?= $usr['email'] ?>" name="email">
									</div>

								</div>

							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleInputPassword1">Username</label>
										<input type="text" class="form-control" value="<?= $usr['username'] ?>" name="username">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleInputPassword1">Password</label>
										<input type="password" class="form-control" placeholder="Isi jika password ingin diubah" name="password">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleSelectBorder">Fakultas</label>
										<select name="id_fakultas" class="custom-select form-control-border">

											<?php foreach ($fakultas as $f) { ?>
												<option value="<?= $f['id_fakultas'] ?>" <?php if ($f['id_fakultas'] == $usr['id_fakultas']) {
																								echo 'selected';
																							} ?>> <?= $f['nama_fakultas'] ?></option>
											<?php } ?>

										</select>
									</div>

								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleSelectBorder">Prodi</label>
										<select name="id_prodi" class="custom-select form-control-border">
											<?php foreach ($jurusan as $j) { ?>
												<option value="<?= $j['id_prodi'] ?>" <?php if ($j['id_prodi'] == $usr['id_prodi']) {
																							echo 'selected';
																						} ?>><?= $j['nama_prodi'] ?></option>
											<?php } ?>


										</select>
									</div>

								</div>
							</div>
							<div class="row">

								<div class="col-md-6">

									<div class="form-group">
										<label for="exampleSelectBorder">Status</label>
										<select name="status" class="custom-select form-control-border">
											<option value="1" <?php if ($usr['status'] == 1) {
																	echo 'selected';
																} ?>>Aktif</option>
											<option value="0" <?php if ($usr['status'] == 0) {
																	echo 'selected';
																} ?>>Tidak Aktif</option>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="exampleSelectBorder">Role</label>
										<select name="id_role" class="custom-select form-control-border">
											<?php foreach ($roles as $r) { ?>
												<option value="<?= $r['id_role'] ?>" <?php if ($r['id_role'] == $usr['id_role']) {
																							echo 'selected';
																						} ?>><?= $r['nama_role'] ?></option>
											<?php } ?>


										</select>
									</div>


								</div>
							</div>



						</div>
						<!-- /.card-body -->


				</div>
				<div class="modal-footer justify-content-between">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

<?php } ?>