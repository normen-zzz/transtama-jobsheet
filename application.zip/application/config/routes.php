<?php
defined('BASEPATH') or exit('No direct script access allowed');

$route['default_controller'] = 'backoffice';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
