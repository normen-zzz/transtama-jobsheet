<?php
defined('BASEPATH') or exit('No direct script access allowed');

class UserModel extends CI_Model
{
	public function getUser($id_jurusan)
	{
		// $ignore = array(1);

		$this->db->select('a.username, a.id_user, a.nama_user, a.email, a.status, b.nama_role, b.id_role, c.id_fakultas, c.nama_fakultas, d.id_prodi, d.nama_prodi');
		$this->db->from('tb_user a');
		$this->db->join('tb_role b', 'a.id_role=b.id_role');
		$this->db->join('tb_fakultas c', 'a.id_fakultas=c.id_fakultas', 'LEFT');
		$this->db->join('tb_jurusan d', 'a.id_prodi=d.id_prodi', 'LEFT');
		if ($id_jurusan != 0) {
			// $this->db->where_not_in('a.id_role', $ignore);
			$this->db->where('a.id_prodi', $id_jurusan);
		}

		$query = $this->db->get();
		return $query;
	}
	public function getUserAdmin()
	{
		$ignore = array(1);
		$this->db->select('a.username, a.id_user, a.nama_user, a.email, a.status, b.nama_role, b.id_role, c.id_fakultas, c.nama_fakultas, d.id_prodi, d.nama_prodi');
		$this->db->from('tb_user a');
		$this->db->join('tb_role b', 'a.id_role=b.id_role');
		$this->db->join('tb_fakultas c', 'a.id_fakultas=c.id_fakultas');
		$this->db->join('tb_jurusan d', 'a.id_prodi=d.id_prodi');
		$this->db->where_not_in('a.id_role', $ignore);
		$query = $this->db->get();
		return $query;
	}
	public function getMhsBimbinganByDosen($id_dosen)
	{
		$this->db->select('a.username, a.id_user, a.nama_user, a.email, a.status,b.id_bimbingan');
		$this->db->from('tb_user a');
		$this->db->join('tbl_mahasiswa_bimbingan b', 'a.id_user=b.id_mhs');
		$this->db->where('b.id_dosen', $id_dosen);
		$query = $this->db->get();
		return $query;
	}
}
