<div class="aside aside-left aside-fixed d-flex flex-column flex-row-auto" id="kt_aside">
    <!--begin::Brand-->
    <div class="brand flex-column-auto" id="kt_brand">
        <!--begin::Logo-->
        <a href="#" class="brand-logo">
            <img class="pt-2" style="width:50%;height:100%;" alt="Logo" src="<?= base_url('uploads/') ?>LogoRaw.png" />
            <?php if ($this->session->userdata('id_role') == 6) {
            ?>
                <span class="text-bold p-3" style="color: #707070;font-weight: bold;">E-Invoice</span>

            <?php } else {
            ?>
                <span class="text-bold p-3" style="color: #707070;font-weight: bold;">Jobsheet</span>

            <?php } ?>
        </a>
        <!--end::Logo-->
        <!--begin::Toggle-->
        <button class="brand-toggle btn btn-sm px-0" id="kt_aside_toggle">
            <span class="svg-icon svg-icon svg-icon-xl">
                <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Angle-double-left.svg-->
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <polygon points="0 0 24 0 24 24 0 24" />
                        <path d="M5.29288961,6.70710318 C4.90236532,6.31657888 4.90236532,5.68341391 5.29288961,5.29288961 C5.68341391,4.90236532 6.31657888,4.90236532 6.70710318,5.29288961 L12.7071032,11.2928896 C13.0856821,11.6714686 13.0989277,12.281055 12.7371505,12.675721 L7.23715054,18.675721 C6.86395813,19.08284 6.23139076,19.1103429 5.82427177,18.7371505 C5.41715278,18.3639581 5.38964985,17.7313908 5.76284226,17.3242718 L10.6158586,12.0300721 L5.29288961,6.70710318 Z" fill="#000000" fill-rule="nonzero" transform="translate(8.999997, 11.999999) scale(-1, 1) translate(-8.999997, -11.999999)" />
                        <path d="M10.7071009,15.7071068 C10.3165766,16.0976311 9.68341162,16.0976311 9.29288733,15.7071068 C8.90236304,15.3165825 8.90236304,14.6834175 9.29288733,14.2928932 L15.2928873,8.29289322 C15.6714663,7.91431428 16.2810527,7.90106866 16.6757187,8.26284586 L22.6757187,13.7628459 C23.0828377,14.1360383 23.1103407,14.7686056 22.7371482,15.1757246 C22.3639558,15.5828436 21.7313885,15.6103465 21.3242695,15.2371541 L16.0300699,10.3841378 L10.7071009,15.7071068 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" transform="translate(15.999997, 11.999999) scale(-1, 1) rotate(-270.000000) translate(-15.999997, -11.999999)" />
                    </g>
                </svg>
                <!--end::Svg Icon-->
            </span>
        </button>
        <!--end::Toolbar-->
    </div>
    <!--end::Brand-->
    <!--begin::Aside Menu-->
    <?php $role = $this->session->userdata('id_role'); ?>
    <div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
        <!--begin::Menu Container-->
        <div id="kt_aside_menu" class="aside-menu my-4" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500">
            <!--begin::Menu Nav-->
            <ul class="menu-nav">
                <!-- jika dia superadmin -->
                <?php if ($role == 1) {
                ?>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('superadmin/dashboard') ?>" class="menu-link">
                            <i class="fa fa-home mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="menu-section">
                        <h4 class="menu-text">JOBSHEET</h4>
                        <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('superadmin/jobsheet') ?>" class="menu-link">
                            <i class="fa fa-book mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Jobsheet</span>
                        </a>
                    </li>

                <?php } elseif ($role == 6) {
                    $total_revisi = $this->db->get_where('tbl_revisi_so', ['status_revisi' => 2])->num_rows(); ?>
                    <!-- keuangan -->
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('finance/dashboard') ?>" class="menu-link">
                            <i class="fa fa-home mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="menu-section">
                        <h4 class="menu-text">JOBSHEET</h4>
                        <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('finance/jobsheet') ?>" class="menu-link">
                            <i class="fa fa-book mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Enter Jobsheet</span>
                        </a>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('finance/jobsheet/final') ?>" class="menu-link">
                            <i class="fa fa-check mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Approve Jobsheet</span>
                        </a>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('finance/jobsheet/viewRevisiSo') ?>" class="menu-link">
                            <i class="fa fa-pen mt-3 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Revisi Jobsheet
                                <pre class="badge badge-danger ml-1"> <?= $total_revisi ?></pre>
                            </span>
                        </a>
                    </li>
                    <li class="menu-section">
                        <h4 class="menu-text">INVOICE</h4>
                        <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
                    </li>
                    <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <i class="fa fa-dollar-sign mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">AR</span>
                            <i class="menu-arrow"></i>
                        </a>

                        <div class="menu-submenu">
                            <i class="menu-arrow"></i>
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?= base_url('finance/invoice') ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text">Proforma Invoice</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?= base_url('finance/invoice/final') ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text">Invoice</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?= base_url('finance/invoice/soa') ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text">SOA</span>
                                    </a>
                                </li>


                            </ul>
                        </div>
                    </li>

                    <li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <i class="fa fa-file-invoice mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">AP</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="menu-submenu">
                            <i class="menu-arrow"></i>
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?= base_url('finance/ap') ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot">
                                            <span></span>
                                        </i>
                                        <span class="menu-text">List Invoice</span>
                                    </a>
                                </li>


                            </ul>
                        </div>
                    </li>


                <?php } elseif ($role == 3) {
                    $total_revisi = $this->db->get_where('tbl_request_revisi', ['status' => 0])->num_rows();
                    $total_so_cs = $this->db->get_where(' tbl_revisi_so', ['status_revisi' => 0])->num_rows();
                    $total_so_mgr = $this->db->get_where(' tbl_revisi_so', ['status_revisi' => 1])->num_rows();

                ?>
                    <!-- cs -->
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/dashboard') ?>" class="menu-link">
                            <i class="fa fa-home mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="menu-section">
                        <h4 class="menu-text">Sales Order</h4>
                        <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/salesOrder') ?>" class="menu-link">
                            <i class="fa fa-dollar-sign mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">List Sales Order</span>
                        </a>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/salesOrder/revisiSo') ?>" class="menu-link">
                            <i class="fa fa-book mt-3 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Request Revisi
                                <pre class="badge badge-danger ml-1"> <?= $total_revisi ?></pre>
                            </span>
                        </a>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/salesOrder/viewRevisiSo') ?>" class="menu-link">
                            <i class="fa fa-pen mt-3 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Revisi Sales Order
                                <pre class="badge badge-danger ml-1"> <?php $id_atasan = $this->session->userdata('id_atasan');
                                                                        if ($id_atasan == NULL || $id_atasan == 0) {
                                                                            echo  $total_so_mgr;
                                                                        } else {
                                                                            echo $total_so_cs;
                                                                        }
                                                                        ?></pre>
                            </span>
                        </a>
                    </li>
                    <li class="menu-section">
                        <h4 class="menu-text">JOBSHEET</h4>
                        <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/jobsheet') ?>" class="menu-link">
                            <i class="fa fa-book mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Jobsheet Approve PIC</span>
                        </a>
                    </li>
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('cs/jobsheet/final') ?>" class="menu-link">
                            <i class="fa fa-book mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Jobsheet Approve Manager</span>
                        </a>
                    </li>


                <?php } elseif ($role == 4) { ?>
                    <!-- marketing -->
                    <li class="menu-item" aria-haspopup="true">
                        <a href="<?= base_url('marketing/dashboard') ?>" class="menu-link">
                            <i class="fa fa-home mt-2 fa-1x mr-2 text-danger"></i>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                <?php } ?>
            </ul>
            <!--end::Menu Nav-->
        </div>
        <!--end::Menu Container-->
    </div>
    <!--end::Aside Menu-->
</div>