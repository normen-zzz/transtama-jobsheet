<center><?= $title ?></center>

<table style="width:100%">
    <thead>
        <tr>
            <th>Customers</th>
            <th>No Invoice</th>
            <th>Shipment</th>
            <!-- <th>Date Created</th> -->
            <th>Due Date</th>
            <th>Tagihan(Rp)</th>
            <th>Invoice</th>
            <th>PPN</th>
            <th>PPH 23</th>
            <th>Total After PPH</th>
            <!-- <th>Action</th> -->
        </tr>
    </thead>
    <tbody>
        <?php
        $total_invoice = 0;
        $invoice = 0;
        $ppn = 0;
        $pph = 0;
        $total_setelah_pph = 0;
        foreach ($proforma as $j) {
        ?>
            <tr>
                <td><?= $j['customer'] ?></td>
                <td><?= "'" . $j['no_invoice'] . "'" ?> </td>
                <td><?= bulan($j['shipment']) ?></td>
                <td><?php
                    echo  bulan_indo($j['due_date']);
                    ?>
                </td>
                <td><?= rupiah($j['total_invoice']) ?></td>
                <td><?= rupiah($j['invoice']) ?></td>
                <td><?= rupiah($j['ppn']) ?></td>
                <td><?= rupiah($j['pph']) ?></td>
                <td><?php $total = $j['total_invoice'] - $j['pph'];
                    echo rupiah($total) ?></td>
            </tr>

        <?php
            $total_invoice += $j['total_invoice'];
            $invoice += $j['invoice'];
            $ppn += $j['ppn'];
            $pph += $j['pph'];
            $total_setelah_pph += $total;
        } ?>
        <tr>
            <td colspan="4" style="text-align:center">Total</td>
            <td><?= rupiah($total_invoice) ?></td>
            <td><?= rupiah($invoice) ?></td>
            <td><?= rupiah($ppn) ?></td>
            <td><?= rupiah($pph) ?></td>
            <td><?= rupiah($total_setelah_pph) ?></td>
        </tr>

    </tbody>

</table>