<div class="d-flex flex-column-fluid">
	<!--begin::Container-->
	<div class="container">
		<!--begin::Dashboard-->
		<div class="row">
			<div class="col-xl-4">
				<!--begin::Stats Widget 16-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-arrow-right text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Enter Jobsheet</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 16-->
			</div>
			<div class="col-xl-4">
				<!--begin::Stats Widget 17-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-check text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Approve Jobsheet</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 17-->
			</div>
			<div class="col-xl-4">
				<!--begin::Stats Widget 18-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-pen text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Revisi Jobsheet</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 18-->
			</div>
		</div>

		<div class="row">
			<div class="col-xl-3">
				<!--begin::Stats Widget 16-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-arrow-right text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Proforma Invoice</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 16-->
			</div>
			<div class="col-xl-3">
				<!--begin::Stats Widget 17-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-dollar-sign text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Invoice</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 17-->
			</div>
			<div class="col-xl-3">
				<!--begin::Stats Widget 18-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-check text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Paid Invoice</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 18-->
			</div>
			<div class="col-xl-3">
				<!--begin::Stats Widget 18-->
				<a href="#" class="card card-custom card-stretch gutter-b">
					<!--begin::Body-->
					<div class="card-body">
						<span class="svg-icon svg-icon-info svg-icon-3x ml-n1">
							<i class="fa fa-calendar text-danger"></i>
						</span>
						<div class="text-inverse-white font-weight-bolder font-size-h5 mb-2 mt-5">100</div>
						<div class="font-weight-bold text-inverse-white font-size-sm">Pending Invoice</div>
					</div>
					<!--end::Body-->
				</a>
				<!--end::Stats Widget 18-->
			</div>
		</div>

	</div>
	<!--end::Container-->
</div>