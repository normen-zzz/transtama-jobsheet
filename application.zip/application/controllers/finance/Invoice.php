<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Invoice extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('id_user')) {
            redirect('backoffice');
        }
        $this->load->library('breadcrumb');
        $this->load->library('upload');
        $this->load->model('M_Datatables');
        $this->load->model('CsModel', 'cs');
        $this->db->query("SET sql_mode=(SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''));");
        cek_role();
    }
    public function index()
    {
        $data['title'] = 'Proforma Invoice';
        $breadcrumb_items = [];
        $data['subtitle'] = 'Proforma Invoice';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['proforma'] = $this->cs->getProformaInvoice()->result_array();
        $this->backend->display('finance/v_proforma_invoice', $data);
    }
    public function final()
    {
        $shipment_id = $this->input->post('shipment_id');
        if ($shipment_id == NULL) {
            $data['title'] = 'Invoice';
            $breadcrumb_items = [];
            $data['subtitle'] = 'Invoice';
            $this->breadcrumb->add_item($breadcrumb_items);
            $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
            $data['proforma'] = $this->cs->getProformaInvoiceFinal()->result_array();
            $this->backend->display('finance/v_invoice', $data);
        } else {
            $cek_data = $this->db->get_where('tbl_shp_order',  ['shipment_id' => $shipment_id])->row_array();
            if ($cek_data) {
                $data['invoice'] = $this->db->get_where('tbl_invoice', ['shipment_id' => $cek_data['id']])->row_array();
                $data['title'] = 'Invoice';
                $data['shipment_id'] = $shipment_id;
                $breadcrumb_items = [];
                $data['subtitle'] = 'Invoice';
                $this->breadcrumb->add_item($breadcrumb_items);
                $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
                $data['proforma'] = $this->cs->getProformaInvoiceFinal()->result_array();
                $this->backend->display('finance/v_invoice', $data);
            } else {
                $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Shipment ID Not Found'));
                redirect('finance/invoice/final');
            }
        }
    }
    public function soa()
    {
        $data['title'] = 'SOA';
        $breadcrumb_items = [];
        $data['subtitle'] = 'SOA';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['proforma'] = $this->cs->getSoa()->result_array();
        $this->backend->display('finance/v_soa', $data);
    }
    public function edit($id_invoice, $no_invoice)
    {

        $data['title'] = 'Edit Invoice';
        $breadcrumb_items = [];
        $data['subtitle'] = 'Edit Invoice';
        // $data['sub_header_page'] = 'exist';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['due_date'] = $this->db->get_where('tbl_invoice', ['no_invoice' => $no_invoice])->row_array();
        $data['shipper'] = $this->db->get_where('tbl_shp_order', ['id' => $id_invoice])->row_array();
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
        $data['moda'] = $this->db->get('tbl_moda')->result_array();
        $data['js'] = $this->cs->getJsApproveFinance()->result_array();

        $this->backend->display('finance/v_edit_invoice', $data);
    }
    public function editInvoice($id_invoice, $no_invoice)
    {

        $data['title'] = 'Edit Invoice';
        $breadcrumb_items = [];
        $data['subtitle'] = 'Edit Invoice';
        // $data['sub_header_page'] = 'exist';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['due_date'] = $this->db->get_where('tbl_invoice', ['no_invoice' => $no_invoice])->row_array();
        $data['shipper'] = $this->db->get_where('tbl_shp_order', ['id' => $id_invoice])->row_array();
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
        $data['moda'] = $this->db->get('tbl_moda')->result_array();
        $data['js'] = $this->cs->getJsApproveFinance()->result_array();

        $this->backend->display('finance/v_edit_invoice_final', $data);
    }
    public function detailInvoice($id_invoice, $no_invoice)
    {

        $data['title'] = 'Detail Invoice';
        $breadcrumb_items = [];
        $data['subtitle'] = 'Detail Invoice';
        // $data['sub_header_page'] = 'exist';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['due_date'] = $this->db->get_where('tbl_invoice', ['no_invoice' => $no_invoice])->row_array();
        $data['shipper'] = $this->db->get_where('tbl_shp_order', ['id' => $id_invoice])->row_array();
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
        $data['js'] = $this->cs->getJsApproveFinance()->result_array();

        $this->backend->display('finance/v_detail_invoice', $data);
    }
    public function paid()
    {
        $data = array(
            'payment_date' => $this->input->post('payment_date'),
            'payment_time' => $this->input->post('payment_time'),
            'status' => 2
        );
        // var_dump($data);
        // $config['upload_path'] = './uploads/berkas/';
        // $config['allowed_types'] = 'jpg|png|jpeg';
        // $config['encrypt_name'] = TRUE;
        // $this->upload->initialize($config);

        // $folderUpload = "./uploads/bukti_bayar/";
        // $files = $_FILES;
        // $files = $_FILES;
        // $jumlahFile = count($files['ktp']['name']);
        // // var_dump($jumlahFile);
        // // die;

        // if (!empty($_FILES['ktp']['name'][0])) {
        //     $listNamaBaru = array();
        //     for ($i = 0; $i < $jumlahFile; $i++) {
        //         $namaFile = $files['ktp']['name'][$i];
        //         $lokasiTmp = $files['ktp']['tmp_name'][$i];

        //         # kita tambahkan uniqid() agar nama gambar bersifat unik
        //         $namaBaru = uniqid() . '-' . $namaFile;

        //         array_push($listNamaBaru, $namaBaru);
        //         $lokasiBaru = "{$folderUpload}/{$namaBaru}";
        //         $prosesUpload = move_uploaded_file($lokasiTmp, $lokasiBaru);
        //     }
        //     $namaBaru = implode("+", $listNamaBaru);
        //     $ktp = array('bukti_bayar' => $namaBaru);
        //     $data = array_merge($data, $ktp);
        // } else {
        //     $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Please Upload Proof of Paymant'));
        //     redirect('finance/invoice/final');
        // }
        // // var_dump($data);
        // // die;
        $update = $this->db->update('tbl_invoice', $data, ['no_invoice' => $this->input->post('no_invoice')]);
        if ($update) {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success Paid'));
            redirect('finance/invoice/final');
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Failed'));
            redirect('finance/invoice/final');
        }
    }
    // public function paid()
    // {
    //     $data = array(
    //         'payment_date' => $this->input->post('payment_date'),
    //         'payment_time' => $this->input->post('payment_time'),
    //         'status' => 2
    //     );
    //     // var_dump($data);
    //     $config['upload_path'] = './uploads/berkas/';
    //     $config['allowed_types'] = 'jpg|png|jpeg';
    //     $config['encrypt_name'] = TRUE;
    //     $this->upload->initialize($config);

    //     $folderUpload = "./uploads/bukti_bayar/";
    //     $files = $_FILES;
    //     $files = $_FILES;
    //     $jumlahFile = count($files['ktp']['name']);
    //     // var_dump($jumlahFile);
    //     // die;

    //     if (!empty($_FILES['ktp']['name'][0])) {
    //         $listNamaBaru = array();
    //         for ($i = 0; $i < $jumlahFile; $i++) {
    //             $namaFile = $files['ktp']['name'][$i];
    //             $lokasiTmp = $files['ktp']['tmp_name'][$i];

    //             # kita tambahkan uniqid() agar nama gambar bersifat unik
    //             $namaBaru = uniqid() . '-' . $namaFile;

    //             array_push($listNamaBaru, $namaBaru);
    //             $lokasiBaru = "{$folderUpload}/{$namaBaru}";
    //             $prosesUpload = move_uploaded_file($lokasiTmp, $lokasiBaru);
    //         }
    //         $namaBaru = implode("+", $listNamaBaru);
    //         $ktp = array('bukti_bayar' => $namaBaru);
    //         $data = array_merge($data, $ktp);
    //     } else {
    //         $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Please Upload Proof of Paymant'));
    //         redirect('finance/invoice/final');
    //     }
    //     // var_dump($data);
    //     // die;
    //     $update = $this->db->update('tbl_invoice', $data, ['no_invoice' => $this->input->post('no_invoice')]);
    //     if ($update) {
    //         $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success Paid'));
    //         redirect('finance/invoice/final');
    //     } else {
    //         $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Please Upload Proof of Payent'));
    //         redirect('finance/invoice/final');
    //     }
    // }

    public function detail($id)
    {
        $data['subtitle'] = 'Detail Sales Order';
        $data['title'] = 'Detail Sales Order';
        $data['msr'] = $this->cs->getDetailSo($id)->row_array();
        // $data['sales'] = $this->db->get_where('tbl_sales', ['id_msr' => $id])->result_array();
        $data['modal'] = $this->db->get_where('tbl_modal', ['shipment_id' => $id])->result_array();
        // var_dump($data['modal']);
        // die;
        $this->backend->display('finance/v_js_detail_mgr', $data);
    }


    public function deleteInvoice($id_invoice, $no_invoice, $shipment_id)
    {
        $delete = $this->db->delete('tbl_invoice',  ['id_invoice' => $id_invoice]);
        if ($delete) {
            $data = array(
                'status_so' => 4
                // 'pu_moda' => $pu_muda[$i]
            );
            $this->db->update('tbl_shp_order', $data, ['shipment_id' => $shipment_id]);
            $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Failed'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        }
    }
    public function approve($no_invoice, $id_invoice, $total_amount)
    {
        $update = $this->db->update('tbl_invoice',  ['status' => 1, 'total_invoice' => decrypt_url($total_amount)], ['no_invoice' => $no_invoice]);
        if ($update) {
            $data = array(
                'no_invoice' => $no_invoice,
                'id_user' => $this->session->userdata('id_user')
            );
            $this->db->insert('tbl_approve_invoice', $data);
            $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success'));
            redirect('finance/invoice/final');
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Failed'));
            redirect('finance/invoice/final');
        }
    }
    public function cekShipmentId()
    {
        $shipment_id = $this->input->post('shipment_id');
        $cek_data = $this->db->get_where('tbl_shp_order',  ['shipment_id' => $shipment_id])->row_array();
        if ($cek_data) {
            $data['invoice'] = $this->db->get_where('tbl_invoice', ['shipment_id' => $cek_data['id']])->row_array();
            $this->backend->display('finance/v_invoice', $data);
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Shipment ID Not Found'));
            redirect('finance/invoice/final');
        }
    }

    public function proceseditInvoice()
    {
        $no_invoice = $this->input->post('no_invoice');
        $terbilang = $this->input->post('terbilang');
        // $pu_muda = $this->input->post('pu_muda');
        $is_reimbursment = $this->input->post('is_reimbursment');
        $is_special = $this->input->post('is_special');
        $is_packing = $this->input->post('is_packing');
        $id_invoice = $this->input->post('id_invoice');
        $due_date = $this->input->post('due_date');
        $total_invoice = $this->input->post('total_invoice');
        $invoice = $this->input->post('invoice');
        $ppn = $this->input->post('ppn');
        $pph = $this->input->post('pph');
        $is_ppn = $this->input->post('is_ppn');
        $is_pph = $this->input->post('is_pph');
        $no_telp = $this->input->post('no_telp');
        $print_do = $this->input->post('print_do');
        $pic = $this->input->post('pic');
        $address = $this->input->post('address');
        $shipper = $this->input->post('shipper');
        $shipment_id =  $this->input->post('shipment_id');
        $note_cs = $this->input->post('note_cs');
        // KALO DIA ADA PPN DAN PPH
        if ($is_ppn != 1) {
            $ppn = 0;
        } else {
            $ppn =  0.011 * $invoice;
        }
        if ($is_pph != 1) {
            $pph = 0;
        } else {
            $pph = 0.02 * $invoice;
        }
        for ($i = 0; $i < sizeof($shipment_id); $i++) {
            $data = array(
                'note_cs' => $note_cs[$i],
                // 'pu_moda' => $pu_muda[$i],
            );
            $this->db->update('tbl_shp_order', $data, ['id' => $shipment_id[$i]]);
        }
        $data = array(
            'due_date' => $due_date,
            'pic' => $pic,
            'terbilang' => $terbilang,
            'no_telp' => $no_telp,
            'address' => $address,
            'print_do' => $print_do,
            'customer' => $shipper,
            'is_reimbursment' => $is_reimbursment,
            'is_special' => $is_special,
            'is_packing' => $is_packing,
            'total_invoice' => $total_invoice,
            'invoice' => $invoice,
            'ppn' => $ppn,
            'pph' => $pph,
            'is_ppn' => $is_ppn,
            'is_pph' => $is_pph,
        );
        $update = $this->db->update('tbl_invoice', $data, ['no_invoice' => $no_invoice]);
        if ($update) {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Failed'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        }
    }
    public function createInvoice()
    {
        $shipment_id =  $this->input->post('shipment_id');
        if ($shipment_id == NULL) {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Please Select Minimun 1 Shipment'));
            redirect('finance/jobsheet/final');
        }
        $data['shipper'] = $this->db->get_where('tbl_shp_order', ['id' => $shipment_id[0]])->row_array();
        // var_dump($data['shipper']);
        // die;
        $data['title'] = 'Create Invoice';
        $breadcrumb_items = [];
        $data['subtitle'] = 'Create Invoice';
        // $data['sub_header_page'] = 'exist';
        $this->breadcrumb->add_item($breadcrumb_items);
        $data['breadcrumb_bootstrap_style'] = $this->breadcrumb->generate();
        $data['shipment_id'] = $shipment_id;
        $this->backend->display('finance/v_create_invoice', $data);
    }
    public function addShipment()
    {
        $shipment_id =  $this->input->post('shipment_id');
        $due_date = $this->input->post('due_date');
        $pic = $this->input->post('pic');
        $no_invoice = $this->input->post('no_invoice');
        $id_invoice = $this->input->post('id_invoice');

        for ($i = 0; $i < sizeof($shipment_id); $i++) {
            $exis_invoice = $this->db->get_where('tbl_invoice', ['shipment_id' => $shipment_id[$i]])->row_array();
            // kalo sudah ada invoice
            if ($exis_invoice) {
                break;
            } else {
                $data = array(
                    'shipment_id' => $shipment_id[$i],
                    'no_invoice' => $no_invoice,
                    'date' => date('Y-m-d'),
                    'due_date' => $due_date,
                    'pic' => $pic,
                    'status' => 0
                );
                $insert = $this->db->insert('tbl_invoice', $data);
                $data = array(
                    'status_so' => 5
                    // 'pu_moda' => $pu_muda[$i]
                );
                $this->db->update('tbl_shp_order', $data, ['id' => $shipment_id[$i]]);
            }
        }
        if ($insert) {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('success', 'Success'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        } else {
            $this->session->set_flashdata('messageAlert', $this->messageAlert('error', 'Duplicate Shipment ID'));
            redirect('finance/invoice/edit/' . $id_invoice . '/' . $no_invoice);
        }
    }
    public function Exportexcel($id)
    {
        $detail = $this->db->get_where('tbl_shp_order', ['id' => $id])->row_array();
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment;Filename=export-invoice-$detail[shipment_id].xls");
        $data['title'] = "Invoice";
        $data['msr'] = $this->cs->getDetailSo($id)->row_array();

        $this->load->view('finance/export_invoice', $data);
    }
    public function ExportSoa()
    {
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment;Filename=export-soa.xls");
        $data['title'] = "SOA";
        $data['proforma'] = $this->cs->getSoa()->result_array();
        $this->load->view('finance/export_soa', $data);
    }
    public function printProforma($no_invoice)
    {
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['info'] = $this->cs->getInvoice($no_invoice)->row_array();

        $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
        // kalo dia ada reimbursment
        if ($data['info']['is_reimbursment'] == 1) {
            $data['reimbursment'] = $this->cs->getInvoiceReimbursment($no_invoice)->row_array();
            $this->load->view('superadmin/v_cetak_invoice_reimbursment', $data);
            $html = $this->output->get_output();
            $this->load->library('dompdf_gen');
            $this->dompdf->set_paper("legal", 'potrait');
            $this->dompdf->load_html($html);
            $this->dompdf->render();
            // $sekarang = date("d:F:Y:h:m:s");
            $this->dompdf->stream("Invoice$no_invoice.pdf", array('Attachment' => 0));
        } else {
            $this->load->view('superadmin/v_cetak_invoice', $data);
            $html = $this->output->get_output();
            $this->load->library('dompdf_gen');
            $this->dompdf->set_paper("legal", 'potrait');
            $this->dompdf->load_html($html);
            $this->dompdf->render();
            // $sekarang = date("d:F:Y:h:m:s");
            $this->dompdf->stream("Invoice$no_invoice.pdf", array('Attachment' => 0));
        }
    }
    public function printProformaFull($no_invoice)
    {
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['info'] = $this->cs->getInvoice($no_invoice)->row_array();
        $get_alamat_customer = $this->db->get_where('tb_customer', ['nama_pt' => $data['info']['shipper']])->row_array();

        $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
        $this->load->view('superadmin/v_cetak_invoice_full', $data);
        $html = $this->output->get_output();
        $this->load->library('dompdf_gen');
        $this->dompdf->set_paper("legal", 'potrait');
        $this->dompdf->load_html($html);
        $this->dompdf->render();
        // $sekarang = date("d:F:Y:h:m:s");
        $this->dompdf->stream("Invoice$no_invoice.pdf", array('Attachment' => 0));
    }
    public function printProformaExcell($no_invoice)
    {
        $data['invoice'] = $this->cs->getInvoice($no_invoice)->result_array();
        $data['info'] = $this->cs->getInvoice($no_invoice)->row_array();
        if ($data['info']['is_reimbursment'] == 1) {
            $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
            header("Content-type: application/octet-stream");
            header("Content-Disposition: attachment;Filename=export-invoice.xls");
            $this->load->view('finance/v_cetak_invoice_excell_reimbursment', $data);
        } else {
            $data['total_invoice'] = $this->cs->getInvoice($no_invoice)->num_rows();
            header("Content-type: application/octet-stream");
            header("Content-Disposition: attachment;Filename=export-invoice.xls");
            $this->load->view('finance/v_cetak_invoice_excell', $data);
        }
    }


    public function messageAlert($type, $title)
    {
        $messageAlert = "
			const Toast = Swal.mixin({
				toast: true,
				position: 'top-end',
				showConfirmButton: false,
				timer: 3000,
				timerProgressBar: true,
				didOpen: (toast) => {
				toast.addEventListener('mouseenter', Swal.stopTimer)
				toast.addEventListener('mouseleave', Swal.resumeTimer)
				}
			})
			
			Toast.fire({
				icon: '$type',
				title: '$title'
			  })
			";
        return $messageAlert;
    }
}
